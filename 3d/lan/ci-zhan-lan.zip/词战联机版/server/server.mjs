import {createRequire as __cr} from 'module'; const require = __cr(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports, module) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
      kListener: Symbol("kListener"),
      kStatusCode: Symbol("status-code"),
      kWebSocket: Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports, module) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = __require("bufferutil");
        module.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports, module) {
    "use strict";
    var kDone = Symbol("kDone");
    var kRun = Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports, module) {
    "use strict";
    var zlib = __require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = Symbol("permessage-deflate");
    var kTotalLength = Symbol("total-length");
    var kCallback = Symbol("callback");
    var kBuffers = Symbol("buffers");
    var kError = Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate2 = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && (typeof params.client_max_window_bits === "number" ? opts.clientMaxWindowBits > params.client_max_window_bits : !params.client_max_window_bits)) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module.exports = PerMessageDeflate2;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports, module) {
    "use strict";
    var { isUtf8 } = __require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = __require("utf-8-validate");
        module.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports, module) {
    "use strict";
    var { Writable } = __require("stream");
    var PerMessageDeflate2 = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver2 = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._numFragments = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate2.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._maxFragments > 0 && ++this._numFragments > this._maxFragments) {
          const error = this.createError(
            RangeError,
            "Too many message fragments",
            false,
            1008,
            "WS_ERR_TOO_MANY_BUFFERED_PARTS"
          );
          cb(error);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._numFragments = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module.exports = Receiver2;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports, module) {
    "use strict";
    var { Duplex } = __require("stream");
    var { randomFillSync } = __require("crypto");
    var {
      types: { isUint8Array }
    } = __require("util");
    var PerMessageDeflate2 = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender2 = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module.exports = Sender2;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports, module) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = Symbol("kCode");
    var kData = Symbol("kData");
    var kError = Symbol("kError");
    var kMessage = Symbol("kMessage");
    var kReason = Symbol("kReason");
    var kTarget = Symbol("kTarget");
    var kType = Symbol("kType");
    var kWasClean = Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports, module) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name, elem) {
      if (dest[name] === void 0) dest[name] = [elem];
      else dest[name].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name = header.slice(start, end);
            if (code === 44) {
              push(offers, name, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension2) => {
        let configurations = extensions[extension2];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension2].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports, module) {
    "use strict";
    var EventEmitter = __require("events");
    var https = __require("https");
    var http = __require("http");
    var net = __require("net");
    var tls = __require("tls");
    var { randomBytes: randomBytes3, createHash } = __require("crypto");
    var { Duplex, Readable } = __require("stream");
    var { URL: URL2 } = __require("url");
    var PerMessageDeflate2 = require_permessage_deflate();
    var Receiver2 = require_receiver();
    var Sender2 = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            if (!options || options.protocols === void 0) {
              protocols = [];
            } else if (Array.isArray(options.protocols)) {
              protocols = options.protocols;
            } else {
              protocols = [options.protocols];
            }
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              if (options.protocols === void 0) {
                protocols = [];
              } else if (Array.isArray(options.protocols)) {
                protocols = options.protocols;
              } else {
                protocols = [options.protocols];
              }
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver2({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender2(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate2.extensionName]) {
          this._extensions[PerMessageDeflate2.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        this._readyState = _WebSocket.CLOSING;
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate2.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 256 * 1024,
        maxFragments: 16 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        protocols: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL2) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL2(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes3(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate2({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate2.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL2(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate2.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate2.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports, module) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = __require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream2(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module.exports = createWebSocketStream2;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports, module) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports, module) {
    "use strict";
    var EventEmitter = __require("events");
    var http = __require("http");
    var { Duplex } = __require("stream");
    var { createHash } = __require("crypto");
    var extension2 = require_extension();
    var PerMessageDeflate2 = require_permessage_deflate();
    var subprotocol2 = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=262144] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=16384] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 256 * 1024,
          maxFragments: 16 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol2.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate2({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension2.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate2.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate2.extensionName]);
              extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest = createHash("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate2.extensionName]) {
          const params = extensions[PerMessageDeflate2.extensionName].params;
          const value = extension2.format({
            [PerMessageDeflate2.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module.exports = WebSocketServer2;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// server/index.ts
import { createServer, get as httpGet } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { networkInterfaces } from "node:os";
import { createSocket } from "node:dgram";
import { extname, join, normalize, resolve as resolve2, sep } from "node:path";
import { fileURLToPath } from "node:url";

// node_modules/ws/wrapper.mjs
var import_stream = __toESM(require_stream(), 1);
var import_extension = __toESM(require_extension(), 1);
var import_permessage_deflate = __toESM(require_permessage_deflate(), 1);
var import_receiver = __toESM(require_receiver(), 1);
var import_sender = __toESM(require_sender(), 1);
var import_subprotocol = __toESM(require_subprotocol(), 1);
var import_websocket = __toESM(require_websocket(), 1);
var import_websocket_server = __toESM(require_websocket_server(), 1);

// server/room.ts
import { randomBytes, randomInt } from "node:crypto";

// src/engine/rules.ts
var CLASSES = ["\u5E76", "\u7EED", "\u62E9", "\u8840"];
var METRIC = { \u5E76: "chain", \u7EED: "cont", \u62E9: "pick", \u8840: "blood" };
var CLASS_NAME = { \u5E76: "\u5E76\u6D41", \u7EED: "\u7EED\u6D41", \u62E9: "\u62E9\u6D41", \u8840: "\u8840\u6D41" };
var TARGET = { \u5E76: 34, \u7EED: 60, \u62E9: 63, \u8840: 81 };
var HP_POOL = 21;
var HP_MIN = 3;
var UNIT_NAMES = ["\u5C0F\u5251", "\u5C0F\u76FE", "\u5C0F\u5492"];
var UNIT_GLYPHS = ["\u5251", "\u76FE", "\u5492"];
var AP_START = 6;
var AP_INCOME = 6;
var AP_CAP = 12;
var BASE_COST = 1;
var AND_COST = 2;
var CLAUSE_MAX = 3;
var TIMELINE = 10;
var MAX_ROUNDS = 12;
var KO_PCT = 0.15;
var LADDER = [0.1, 0.25, 0.45, 0.7];
var LADDER_VALUES = [2, 3, 4, 5];
var LADDER_COPIES = 2;
var DICE_HP = 4;
var DICE_COUNT = 2;
var FLOOR = { 3: 2, 5: 3, 7: 4 };
var B_CLAUSES = 7;
var B_AND = 1;
var B_BONUS = 1;
var B_LEN = 0;
var B_WIND = 0;
var X_SLOTS = 3;
var Y_DICE = true;
var DECK_SIZE = 10;
var COPY_MAX = 2;
var KW_SLOTS = 3;
var WORDS = {
  \u6613\u4F24: { price: 1, kind: "status", on: "enemy", desc: "\u7ED9\u654C\u4EBA\u4E0A\u6613\u4F24\uFF1A\u6BCF\u7EA7\u8BA9\u5B83\u6BCF\u6B21\u591A\u53D7 1 \u70B9\u4F24\u5BB3\u3002\u6BCF\u8FC7\u4E00\u8F6E\u81EA\u52A8 +1 \u7EA7" },
  \u707C\u70E7: { price: 1, kind: "status", on: "enemy", desc: "\u7ED9\u654C\u4EBA\u4E0A\u707C\u70E7\uFF1A\u6BCF\u8F6E\u7ED3\u675F\u65F6\uFF0C\u6BCF\u7EA7\u8BA9\u5B83\u6389 1 \u70B9\u8840\u3002\u6BCF\u8FC7\u4E00\u8F6E\u81EA\u52A8 +1 \u7EA7" },
  \u8870\u5F31: { price: 1, kind: "status", on: "enemy", desc: "\u7ED9\u654C\u4EBA\u4E0A\u8870\u5F31\uFF1A\u6BCF\u7EA7\u8BA9\u5B83\u6BCF\u6B21\u5C11\u6253 1 \u70B9\u4F24\u5BB3\u3002\u6BCF\u8FC7\u4E00\u8F6E\u81EA\u52A8 +1 \u7EA7" },
  \u8F6C\u79FB: { price: 2, kind: "redirect", on: "ally", desc: "\u672C\u8F6E\u6253\u5411\u8FD9\u4E2A\u968F\u4ECE\u7684\u654C\u65B9\u4F24\u5BB3\uFF0C\u8F6C\u7ED9\u51FA\u624B\u7684\u4EBA" },
  \u5EF6\u540E: { price: 1, kind: "delay", on: "act", desc: "\u628A\u5BF9\u65B9\u5DF2\u5BA3\u544A\u7684\u4E00\u53E5\u5F80\u540E\u63A8 N \u79D2\uFF1B\u63A8\u51FA\u65F6\u95F4\u8F74\u5C31\u843D\u7A7A" },
  \u79FB\u9664: { price: 1, kind: "remove", on: "enemy", desc: "\u62C6\u6389\u4E00\u4E2A\u654C\u4EBA\u8EAB\u4E0A\u7684\u51CF\u4F24\u3001\u8F6C\u79FB\uFF0C\u5E76\u6390\u65AD\u5B83\u6302\u7740\u7684\u7EED" }
};
var WORD_ORDER = ["\u6613\u4F24", "\u707C\u70E7", "\u8870\u5F31", "\u8F6C\u79FB", "\u5EF6\u540E", "\u79FB\u9664"];
var ENEMY_ST = ["\u6613\u4F24", "\u707C\u70E7", "\u8870\u5F31"];
var KEYWORDS = { \u9996\u6321: "\u6BCF\u8F6E\u7B2C\u4E00\u6B21\u88AB\u654C\u4EBA\u6253\u4E2D\uFF0C\u6574\u4E0B\u6321\u6389", \u4E0D\u5C48: "\u6BCF\u8F6E\u7B2C\u4E00\u6B21\u88AB\u6253\u5230 0 \u8840\uFF0C\u7559 1 \u8840" };
var PRESETS = {
  \u5E76: { words: { \u6613\u4F24: 2, \u707C\u70E7: 1, \u8870\u5F31: 2, \u8F6C\u79FB: 2, \u5EF6\u540E: 1, \u79FB\u9664: 2 }, kws: ["\u4E0D\u5C48", "\u9996\u6321", "\u9996\u6321"] },
  \u7EED: { words: { \u6613\u4F24: 2, \u707C\u70E7: 2, \u8870\u5F31: 2, \u8F6C\u79FB: 1, \u5EF6\u540E: 1, \u79FB\u9664: 2 }, kws: ["\u9996\u6321", "\u4E0D\u5C48", "\u4E0D\u5C48"] },
  \u62E9: { words: { \u6613\u4F24: 2, \u707C\u70E7: 1, \u8870\u5F31: 1, \u8F6C\u79FB: 2, \u5EF6\u540E: 2, \u79FB\u9664: 2 }, kws: ["\u9996\u6321", "\u4E0D\u5C48", "\u9996\u6321"] },
  \u8840: { words: { \u6613\u4F24: 2, \u707C\u70E7: 2, \u8870\u5F31: 1, \u8F6C\u79FB: 2, \u5EF6\u540E: 1, \u79FB\u9664: 2 }, kws: ["\u4E0D\u5C48", "\u4E0D\u5C48", "\u9996\u6321"] }
};
function presetDeck(cls) {
  const p = PRESETS[cls];
  return { cls, words: { ...p.words }, kws: [...p.kws], hp: [7, 7, 7] };
}
function caps(cls, _p) {
  const o = { clauses: CLAUSE_MAX, and: AND_COST, slots: 0, blood: 0, late: false, wind: 1, once: false, cont_single: false, freecount: false, norep: false, noheal: false, nodef: false };
  if (cls === "\u5E76") {
    o.clauses = B_CLAUSES;
    o.and = B_AND;
    o.wind = B_WIND;
    o.once = true;
  } else if (cls === "\u7EED") {
    o.slots = X_SLOTS;
    o.cont_single = true;
  } else if (cls === "\u62E9") {
    o.late = true;
    o.freecount = true;
    o.norep = true;
  } else {
    o.blood = 99;
    o.noheal = true;
    o.nodef = true;
  }
  return o;
}
function deckProblem(words, kws) {
  let n = 0;
  for (const w in words) {
    if (!WORDS[w]) return `\u6CA1\u6709\u3010${w}\u3011\u8FD9\u4E2A\u8FDB\u9636\u8BCD`;
    if (words[w] > COPY_MAX) return `\u3010${w}\u3011\u6700\u591A\u5E26 ${COPY_MAX} \u5F20`;
    n += words[w];
  }
  if (n !== DECK_SIZE) return `\u5361\u7EC4\u8981\u6B63\u597D ${DECK_SIZE} \u5F20\u8FDB\u9636\u8BCD\uFF08\u73B0\u5728 ${n} \u5F20\uFF09`;
  if (kws.length !== KW_SLOTS) return `\u8981\u9009 ${KW_SLOTS} \u4E2A\u5173\u952E\u8BCD\uFF08\u6BCF\u4E2A\u968F\u4ECE\u4E00\u4E2A\uFF09`;
  for (const k of kws) if (!KEYWORDS[k]) return `\u6CA1\u6709\u3010${k}\u3011\u8FD9\u4E2A\u5173\u952E\u8BCD`;
  return "";
}
var CLASS_WORD = { \u5E76: "\u5E76", \u7EED: "\u6301\u7EED", \u62E9: "\u9009\u62E9", \u8840: "\u81EA\u8EAB" };
var CLASS_TALENT = {
  \u5E76: `\u4E0A\u9650\uFF1A\u4E00\u53E5\u6700\u591A ${B_CLAUSES} \u6BB5\uFF08\u522B\u4EBA 3 \u6BB5\uFF09\uFF0C\u6BCF\u591A\u4E00\u6BB5\u53EA\u52A0 ${B_AND} \u884C\u52A8\u70B9\uFF08\u522B\u4EBA 2\uFF09\uFF0C\u8D77\u624B\u4E0D\u56E0\u4E3A\u6BB5\u591A\u53D8\u665A\u3002\u9650\u5236\uFF1A\u4E00\u53E5\u91CC\u540C\u4E00\u4E2A\u52A8\u4F5C\u8BCD\uFF08\u9020\u6210\u3001\u6062\u590D\u3001\u51CF\u4F24\u3001\u6613\u4F24\u3001\u707C\u70E7\u3001\u8870\u5F31\u3001\u8F6C\u79FB\u3001\u5EF6\u540E\u3001\u79FB\u9664\uFF09\u53EA\u80FD\u7528\u4E00\u6B21`,
  \u7EED: `\u4E0A\u9650\uFF1A\u3010\u6301\u7EED\u3011\u80FD\u63A5\u5728 \u9020\u6210\u3001\u6062\u590D\u3001\u51CF\u4F24 \u540E\u9762\uFF0C\u8FD9\u4E00\u6BB5\u4EE5\u540E\u6BCF\u8F6E\u540C\u4E00\u79D2\u81EA\u52A8\u518D\u6765\u4E00\u6B21\uFF08\u4E0D\u82B1\u884C\u52A8\u70B9\uFF09\uFF0C\u540C\u65F6\u80FD\u6302 ${X_SLOTS} \u4E2A\u7EED\u3002\u9650\u5236\uFF1A\u5E26\u3010\u6301\u7EED\u3011\u7684\u8FD9\u53E5\u53EA\u80FD\u4E00\u6BB5\uFF0C\u4E0D\u80FD\u63A5\u3010\u5E76\u3011\u3002\u51FA\u624B\u7684\u968F\u4ECE\u5012\u4E0B\u6216\u88AB\u3010\u79FB\u9664\u3011\uFF0C\u5B83\u7684\u7EED\u5C31\u65AD\u4E86`,
  \u62E9: "\u4E0A\u9650\uFF1A\u3010\u9009\u62E9\u3011\u51E0\u4E2A\u76EE\u6807\u4E0D\u7528\u6570\u5B57\u724C\uFF0C\u60F3\u9009\u51E0\u4E2A\u9009\u51E0\u4E2A\uFF1B\u76EE\u6807\u5BA3\u544A\u65F6\u4E0D\u5B9A\uFF08\u5BF9\u624B\u53EA\u770B\u5230\u201C\u5F85\u5B9A\u201D\uFF09\uFF0C\u53CC\u65B9\u5BA3\u544A\u5B8C\u518D\u5B9A\uFF0C\u5B9A\u597D\u7684\u4EBA\u5012\u4E86\u81EA\u52A8\u6362\u4EBA\u3002\u9650\u5236\uFF1A\u53E5\u5B50\u91CC\u4E0D\u80FD\u7528\u3010\u91CD\u590D\u3011",
  \u8840: "\u4E0A\u9650\uFF1A\u884C\u52A8\u70B9\u4E0D\u591F\u65F6\uFF0C\u7528\u51FA\u624B\u968F\u4ECE\u7684\u751F\u547D\u6765\u4ED8\uFF0C\u60F3\u4ED8\u591A\u5C11\u4ED8\u591A\u5C11\uFF081 \u70B9\u751F\u547D\u9876 1 \u70B9\u884C\u52A8\u70B9\uFF0C\u81F3\u5C11\u7559 1 \u8840\uFF09\u3002\u9650\u5236\uFF1A\u7528\u8840\u4ED8\u7684\u53E5\u5B50\u91CC\u4E0D\u80FD\u6709\u3010\u6062\u590D\u3011\u3010\u51CF\u4F24\u3011\u3010\u8F6C\u79FB\u3011"
};
var CLASS_GOAL = {
  \u5E76: "\u8FDE\u6BB5\u5206\uFF1A\u4E24\u6BB5\u4EE5\u4E0A\u7684\u53E5\u5B50\u91CC\uFF0C\u5151\u73B0\u4E86\u51E0\u6BB5\u5C31\u5F97\u51E0\u5206\uFF1B\u6574\u53E5\u6BCF\u6BB5\u90FD\u5151\u73B0\u518D +1",
  \u7EED: "\u7EED\u51FA\u6765\u7684\u6548\u679C\uFF1A\u7EED\u81EA\u52A8\u518D\u6765\u7684\u90A3\u51E0\u6B21\u6253\u51FA\u7684\u4F24\u5BB3\u3001\u56DE\u7684\u8840\u3001\u6321\u4E0B\u7684\u4F24\u5BB3\uFF0C\u52A0\u4E0A\u4F60\u4E0A\u7684\u707C\u70E7\u70E7\u6389\u7684\u3001\u6613\u4F24\u591A\u6253\u7684\u3001\u8870\u5F31\u8BA9\u5BF9\u65B9\u5C11\u6253\u7684",
  \u62E9: "\u547D\u4E2D\uFF1A\u5BF9\u654C\u4EBA\u5B9E\u9645\u6253\u6389\u7684\u8840\uFF08\u6253\u7A7A\u3001\u88AB\u6321\u6389\u7684\u4E0D\u7B97\uFF09",
  \u8840: "\u8840\u503A\uFF1A\u7528\u751F\u547D\u4ED8\u6389\u7684\u70B9\u6570\uFF0C\u52A0\u4E0A\u7528\u8840\u4ED8\u7684\u53E5\u5B50\u5BF9\u654C\u4EBA\u6253\u6389\u7684\u8840"
};
var RULES_LINES = [
  `\xB7 \u53CC\u65B9\u5404 3 \u4E2A\u968F\u4ECE\uFF0C\u5171 ${HP_POOL} \u70B9\u751F\u547D\u3002\u88AB\u51FB\u5012\u7684\u968F\u4ECE\u4F11\u6574\u4E00\u8F6E\uFF0C\u518D\u6EE1\u8840\u56DE\u6765\u3002`,
  "\xB7 \u6BCF\u8F6E\u8F6E\u6D41\u5BA3\u544A\uFF1A\u4E00\u65B9\u5B9A\u4E00\u4E2A\u968F\u4ECE\u7684\u4E00\u53E5\uFF0C\u53E6\u4E00\u65B9\u518D\u5B9A\u4E00\u4E2A\uFF0C\u4EA4\u66FF\u8FDB\u884C\uFF1B\u6BCF\u8F6E\u6362\u4E00\u65B9\u5148\u5B9A\u3002\u4F60\u80FD\u770B\u5230\u5BF9\u65B9\u5DF2\u7ECF\u5B9A\u4E0B\u7684\u53E5\u5B50\uFF08\u62E9\u6D41\u7684\u76EE\u6807\u9664\u5916\uFF09\u3002",
  "\xB7 \u4E00\u53E5\u8BDD\u5C31\u662F\u4E00\u5F20\u5F20\u8BCD\u62FC\u8D77\u6765\u7684\uFF1A\u6BD4\u5982 \u9009\u62E9 2 \u4E2A \u654C\u65B9 \u968F\u4ECE\uFF0C\u9020\u6210 3 \u70B9 \u4F24\u5BB3\uFF0C\u91CD\u590D 2 \u6B21\u3002\u6570\u5B57\u90FD\u662F\u724C\uFF1A1 \u514D\u8D39\u65E0\u9650\u7528\uFF0C2 \u4EE5\u4E0A\u8981\u7528\u624B\u91CC\u7684\u6570\u5B57\u724C\uFF0C\u6BCF\u4E2A\u4F4D\u7F6E\u4E00\u5F20\u3002",
  `\xB7 \u6570\u5B57\u724C\u4ECE\u54EA\u6765\uFF1A\u4F60\u7684\u804C\u4E1A\u5F97\u5206\u5230 10%\u300125%\u300145%\u300170% \u65F6\uFF0C\u5404\u89E3\u9501\u4E24\u5F20 2\u30013\u30014\u30015\uFF08\u80FD\u53CD\u590D\u7528\uFF0C\u7528\u5B8C\u51B7\u5374\u4E00\u8F6E\uFF09\uFF1B\u4E00\u8F6E\u91CC\u6389\u4E86 ${DICE_HP} \u70B9\u4EE5\u4E0A\u8840\u6216\u6709\u968F\u4ECE\u5012\u4E0B\uFF0C\u63B7\u4E24\u4E2A\u9AB0\u5B50\uFF0C\u63B7\u51FA\u51E0\u7ED9\u4E00\u5F20\u51E0\uFF08\u53EA\u80FD\u7528\u4E00\u6B21\uFF09\uFF1B\u7B2C 3\u30015\u30017 \u8F6E\u5F00\u59CB\u65F6\u5404\u53D1\u4E00\u5F20\u4FDD\u5E95\u6570\u5B57 2\u30013\u30014\uFF08\u80FD\u53CD\u590D\u7528\uFF09\u3002`,
  `\xB7 \u884C\u52A8\u70B9\uFF1A\u5F00\u5C40 ${AP_START}\uFF0C\u6BCF\u8F6E +${AP_INCOME}\uFF0C\u6700\u591A ${AP_CAP}\u3002\u4E00\u53E5\u7684\u82B1\u8D39 = ${BASE_COST} + \u8FDB\u9636\u8BCD\u4EF7\u683C + \u6BCF\u591A\u4E00\u6BB5\uFF08\u5E76\uFF09${AND_COST}\u3002`,
  `\xB7 \u65F6\u95F4\u8F74 0~${TIMELINE} \u79D2\uFF1A\u4E00\u53E5\u6700\u65E9\u7B2C\uFF081 + \u8FDB\u9636\u8BCD\u6570 + \u6BB5\u6570 \u2212 1\uFF09\u79D2\u8D77\u6548\uFF1B\u540C\u4E00\u79D2\u91CC\u51CF\u4F24\u3001\u8F6C\u79FB\u8FD9\u7C7B\u4FDD\u62A4\u5148\u751F\u6548\uFF1B\u51FA\u624B\u7684\u968F\u4ECE\u5148\u88AB\u6253\u5012\uFF0C\u5B83\u7684\u62DB\u5C31\u843D\u7A7A\u3002`,
  `\xB7 \u8FDB\u9636\u8BCD\u8981\u7EC4\u8FDB\u5361\u7EC4\uFF08${DECK_SIZE} \u5F20\uFF0C\u540C\u540D\u6700\u591A ${COPY_MAX} \u5F20\uFF09\uFF1B\u7528\u8FC7\u7684\u90A3\u4E00\u5F20\u4E0B\u4E00\u8F6E\u51B7\u5374\u3002\u8FDB\u9636\u8BCD\uFF1A\u6613\u4F24\u3001\u707C\u70E7\u3001\u8870\u5F31\uFF08\u72B6\u6001\uFF0C\u6BCF\u8FC7\u4E00\u8F6E\u81EA\u5DF1 +1 \u7EA7\uFF09\u3001\u8F6C\u79FB\u3001\u5EF6\u540E\u3001\u79FB\u9664\u3002`,
  "\xB7 \u56DB\u4E2A\u804C\u4E1A\uFF0C\u5404\u64C5\u957F\u4E00\u4E2A\u57FA\u7840\u8BCD\uFF1A",
  ...["\u5E76", "\u7EED", "\u62E9", "\u8840"].map((c) => `    ${CLASS_NAME[c]}\uFF08${CLASS_WORD[c]}\uFF09\uFF1A${CLASS_TALENT[c]}\u3002\u5F97\u5206\uFF1A${CLASS_GOAL[c]}\u3002`),
  `\xB7 \u5148\u5230\u81EA\u5DF1\u76EE\u6807\u5206\u7684\u8D62\uFF1B\u51FB\u5012\u4E00\u4E2A\u654C\u4EBA\u7B97\u76EE\u6807\u5206\u7684 15%\uFF1B\u6253\u6EE1 ${MAX_ROUNDS} \u8F6E\u6BD4\u5B8C\u6210\u7684\u767E\u5206\u6BD4\u3002`
];
var hpProblem = (hps) => {
  if (hps.length !== 3) return "\u8981\u7ED9\u4E09\u4E2A\u968F\u4ECE\u5404\u5206\u4E00\u4EFD\u751F\u547D";
  let t = 0;
  for (const h of hps) {
    if (h < HP_MIN) return `\u6BCF\u4E2A\u968F\u4ECE\u81F3\u5C11 ${HP_MIN} \u70B9\u751F\u547D`;
    t += h;
  }
  return t !== HP_POOL ? `\u751F\u547D\u603B\u548C\u8981\u6B63\u597D ${HP_POOL}\uFF08\u73B0\u5728 ${t}\uFF09` : "";
};

// src/engine/engine.ts
var metric0 = () => ({ chain: 0, cont: 0, pick: 0, blood: 0, dmg: 0 });
function newR(U, cls) {
  return { U, M: [metric0(), metric0()], cls: [...cls], kob: [0, 0], kos: [0, 0], fz: [0, 0], lost: [0, 0], maxhit: 0, conts: [], eff: {}, retarget: [0, 0], ev: null };
}
function cloneR(R) {
  const U = R.U.map((u) => {
    const st = {};
    for (const k in u.st) st[k] = [...u.st[k]];
    return { ...u, st, lis: u.lis.map((l) => ({ ...l })), msrc: [...u.msrc] };
  });
  return {
    U,
    M: [{ ...R.M[0] }, { ...R.M[1] }],
    cls: R.cls,
    kob: [...R.kob],
    kos: [0, 0],
    fz: [0, 0],
    lost: [0, 0],
    maxhit: 0,
    conts: R.conts.map((c) => structuredClone(c)),
    eff: {},
    retarget: [0, 0],
    ev: null
  };
}
var prog = (R, s, cls) => R.M[s][METRIC[cls]] / TARGET[cls] + R.kob[s];
var ev = (R, d) => {
  if (R.ev) R.ev.push(d);
};
var credit = (R, s, key, v) => {
  if (v > 0) R.M[s][key] += v;
};
var ekey = (ord, ci) => `${ord}:${ci}`;
var alive = (u) => u.down === -1 && u.hp > 0;
var same = (a, b) => a.length === b.length && a.every((x, i) => x === b[i]);
function dmgTo(R, src, tu, amt) {
  if (amt <= 0 || tu.down !== -1) return 0;
  const dealt = tu.hp > 0 ? Math.min(amt, tu.hp) : 0;
  tu.hp -= amt;
  tu.last = src;
  if (src !== tu.side) {
    R.M[src].dmg += dealt;
    R.lost[tu.side] += dealt;
  }
  return dealt;
}
function hit(R, a, ci, cu, tu, base, t) {
  const s = a.side, o = tu.side;
  if (tu.down !== -1 || tu.hp <= 0) return 0;
  const cls = R.cls;
  const isCont = !!a.is_cont, enemy = s !== o;
  let amt = base;
  const v = tu.st["\u6613\u4F24"];
  const vl = v ? v[0] : 0;
  amt += vl;
  const parts = {};
  const wk = cu.st["\u8870\u5F31"];
  if (wk && amt > 0) {
    const r = Math.min(wk[0], amt);
    amt -= r;
    if (enemy && wk[2] === o && cls[o] === "\u7EED") credit(R, o, "cont", r);
    if (r > 0) parts["\u8870\u5F31"] = r;
  }
  if (tu.mit > 0 && amt > 0) {
    const r3 = Math.min(tu.mit, amt);
    amt -= r3;
    if (enemy) {
      for (const key of tu.msrc) R.eff[key] = true;
      if (cls[o] === "\u7EED" && tu.mitc > 0) credit(R, o, "cont", Math.min(r3, tu.mitc));
    }
    if (r3 > 0) parts["\u51CF\u4F24"] = r3;
  }
  if (amt > 0 && enemy && (tu.shield ?? 0) > 0) {
    const r4 = Math.min(tu.shield, amt);
    tu.shield -= r4;
    amt -= r4;
    parts["\u8840\u75C2"] = r4;
  }
  if (amt > 0 && enemy && tu.kw === "\u9996\u6321" && !tu.kws) {
    tu.kws = true;
    parts["\u9996\u6321"] = amt;
    amt = 0;
  }
  let back = 0;
  if (amt > 0 && enemy) {
    for (const l of tu.lis) if (l.k === "redirect") {
      back = amt;
      amt = 0;
      R.eff[l.src] = true;
      parts["\u8F6C\u79FB"] = back;
      break;
    }
  }
  const dealt = dmgTo(R, s, tu, amt);
  if (enemy && dealt > 0) {
    R.eff[ekey(a.ord, ci)] = true;
    switch (cls[s]) {
      case "\u62E9":
        credit(R, s, "pick", dealt);
        break;
      case "\u8840":
        if ((a.blood ?? 0) > 0) credit(R, s, "blood", dealt);
        break;
      case "\u7EED":
        if (isCont) credit(R, s, "cont", dealt);
        else if (vl > 0 && v[2] === s) credit(R, s, "cont", Math.min(vl, dealt));
        break;
    }
  }
  ev(R, { t, type: "hit", src: cu.uid, tgt: tu.uid, amount: amt, dealt, parts, vuln: vl, cont: isCont });
  if (back > 0 && cu.down === -1 && cu.hp > 0) {
    const d2 = dmgTo(R, o, cu, back);
    if (cls[o] === "\u62E9") credit(R, o, "pick", d2);
    ev(R, { t, type: "redirected", src: tu.uid, tgt: cu.uid, amount: back, dealt: d2 });
  }
  return dealt;
}
function fizzle(R, a, t, why) {
  R.fz[a.side]++;
  ev(R, { t, type: "fizzle", ord: a.ord, uid: a.uid, why, cont: !!a.is_cont });
}
function lateTargets(R, a, cl, acts) {
  const s = a.side;
  const wantEnemy = (cl.side ?? "enemy") === "enemy";
  const pool = R.U.filter((u) => alive(u) && u.side !== s === wantEnemy);
  const n = Math.min(cl.count ?? 1, pool.length);
  const pre = [];
  for (const x of cl.tg ?? []) {
    const uu = R.U[x];
    if (alive(uu) && pool.includes(uu) && !pre.includes(x) && pre.length < n) pre.push(x);
  }
  if (pre.length >= n) return pre;
  if ((cl.tg ?? []).length > 0) R.retarget[s]++;
  const rest = pool.filter((u) => !pre.includes(u.uid));
  const score = {};
  switch (cl.k) {
    case "atk": {
      const pend = {};
      for (const b of acts) if (!b.done && b.side !== s) pend[b.uid] = (pend[b.uid] ?? 0) + 1;
      const rep = cl.rep ?? 1;
      for (const u3 of rest) {
        const vv = u3.st["\u6613\u4F24"];
        const eff = (cl.n + (vv ? vv[0] : 0) - u3.mit) * rep;
        const kill = eff >= u3.hp && !(u3.kw === "\u9996\u6321" && !u3.kws);
        score[u3.uid] = (kill ? 1e3 : 0) + (kill ? 100 * (pend[u3.uid] ?? 0) : 0) - u3.hp;
      }
      break;
    }
    case "heal":
      for (const u of rest) score[u.uid] = u.mx - u.hp;
      break;
    case "mit": {
      const thr = {};
      for (const b2 of acts) {
        if (!b2.done && b2.side !== s) {
          for (const c2 of b2.cl) if (c2.k === "atk") for (const x2 of c2.tg ?? []) thr[x2] = (thr[x2] ?? 0) + c2.n * (c2.rep ?? 1);
        }
      }
      for (const u of rest) score[u.uid] = 10 * (thr[u.uid] ?? 0) - u.hp;
      break;
    }
    case "st":
      for (const u of rest) {
        const e = u.st[cl.st];
        score[u.uid] = -10 * (e ? e[0] : 0) - u.hp;
      }
      break;
    default:
      for (const u of rest) score[u.uid] = -u.hp;
  }
  rest.sort((x, y) => score[y.uid] - score[x.uid]);
  for (const u8 of rest) {
    if (pre.length >= n) break;
    pre.push(u8.uid);
  }
  return pre;
}
function fire(R, a, acts, rnd, t) {
  const s = a.side, U = R.U, cu = U[a.uid], cls = R.cls, isCont = !!a.is_cont;
  let tot = 0;
  ev(R, { t, type: "fire", ord: a.ord, uid: a.uid, cont: isCont, side: s });
  a.cl.forEach((cl, ci) => {
    let tg = cl.tg ?? [];
    if (cl.tmode === "late") {
      const before = [...tg];
      tg = lateTargets(R, a, cl, acts);
      ev(R, { t, type: "lock", ord: a.ord, uid: a.uid, tgts: tg, changed: !same(before, tg) && before.length > 0 });
    }
    switch (cl.k) {
      case "atk":
        for (let r = 0; r < cl.rep; r++) for (const tid of tg) tot += hit(R, a, ci, cu, U[tid], cl.n, t);
        break;
      case "heal":
        for (let r = 0; r < cl.rep; r++) for (const tid of tg) {
          const tu = U[tid];
          if (tu.down !== -1) continue;
          const eff = Math.min(cl.n, tu.mx - tu.hp);
          if (eff > 0) {
            tu.hp += eff;
            if (tu.side === s) {
              R.eff[ekey(a.ord, ci)] = true;
              if (cls[s] === "\u7EED" && isCont) credit(R, s, "cont", eff);
            }
            ev(R, { t, type: "heal", src: cu.uid, tgt: tu.uid, amount: eff, cont: isCont });
          }
        }
        break;
      case "mit":
        for (const tid of tg) {
          const tu = U[tid];
          if (tu.down === -1) {
            tu.mit += cl.n;
            if (isCont) tu.mitc += cl.n;
            tu.msrc.push(ekey(a.ord, ci));
            ev(R, { t, type: "mit", tgt: tu.uid, amount: cl.n, cont: isCont });
          }
        }
        break;
      case "st":
        for (const tid of tg) {
          const tu = U[tid];
          if (tu.down !== -1) continue;
          const e = tu.st[cl.st];
          if (e) {
            e[0] += 1;
            e[1] = Math.max(e[1], rnd + cl.n - 1);
          } else tu.st[cl.st] = [1, rnd + cl.n - 1, s];
          R.eff[ekey(a.ord, ci)] = true;
          ev(R, { t, type: "status", tgt: tu.uid, st: cl.st, lv: tu.st[cl.st][0], end: tu.st[cl.st][1] });
        }
        break;
      case "redirect":
        for (const tid of tg) {
          const tu = U[tid];
          if (tu.down === -1) {
            tu.lis.push({ k: "redirect", side: s, src: ekey(a.ord, ci) });
            ev(R, { t, type: "listen", tgt: tu.uid, k: "redirect" });
          }
        }
        break;
      case "delay":
        for (const b of acts) {
          if (b.ord === cl.act && !b.done) {
            b.start += cl.n;
            R.eff[ekey(a.ord, ci)] = true;
            ev(R, { t, type: "delay", ord: b.ord, sec: cl.n, to: b.start });
            if (b.start > TIMELINE) {
              b.done = true;
              fizzle(R, b, t, "\u88AB\u63A8\u51FA\u4E86\u65F6\u95F4\u8F74");
            }
          }
        }
        break;
      case "remove":
        if (tg.length > 0) {
          const tu = U[tg[0]];
          if (tu.down === -1) {
            const had = tu.mit > 0 || tu.lis.length > 0;
            const broke = R.conts.filter((c) => c.uid === tu.uid).length;
            R.conts = R.conts.filter((c) => c.uid !== tu.uid);
            tu.lis = [];
            tu.mit = 0;
            tu.mitc = 0;
            tu.msrc = [];
            if (had || broke > 0) R.eff[ekey(a.ord, ci)] = true;
            ev(R, { t, type: "remove", tgt: tu.uid, broke });
          }
        }
        break;
    }
    if ((cl.cont ?? 1) > 1 && !isCont) {
      const c2 = structuredClone(cl);
      delete c2.cont;
      c2.tg = [...tg];
      if (c2.tmode === "late") c2.tmode = "choose";
      R.conts.push({ side: s, uid: a.uid, cl: c2, start: a.start, left: cl.cont - 1 });
      ev(R, { t, type: "cont_set", uid: a.uid, rounds: cl.cont - 1 });
    }
  });
  if (tot > R.maxhit) R.maxhit = tot;
}
function koCheck(R, rnd, t) {
  for (const u of R.U) {
    if (u.down === -1 && u.hp <= 0) {
      if (u.kw === "\u4E0D\u5C48" && !u.kws) {
        u.kws = true;
        u.hp = 1;
        ev(R, { t, type: "endure", tgt: u.uid });
        continue;
      }
      u.down = rnd;
      u.hp = 0;
      u.st = {};
      u.lis = [];
      u.mit = 0;
      u.mitc = 0;
      u.msrc = [];
      const broke = R.conts.filter((c) => c.uid === u.uid).length;
      R.conts = R.conts.filter((c) => c.uid !== u.uid);
      const k = u.last;
      if (k != null && k !== u.side) R.kob[k] += KO_PCT;
      R.kos[u.side]++;
      ev(R, { t, type: "ko", tgt: u.uid, by: k ?? -1, broke });
    }
  }
}
function contActs(R) {
  return R.conts.map((c, i) => ({
    side: c.side,
    uid: c.uid,
    start: c.start,
    cl: [c.cl],
    is_cont: true,
    ord: 1e3 + i,
    def: ["mit", "heal"].includes(c.cl.k),
    blood: 0,
    cost: 0
  }));
}
var KIND_NAME = { atk: "\u4F24\u5BB3", heal: "\u6062\u590D", mit: "\u51CF\u4F24", st: "\u72B6\u6001", redirect: "\u8F6C\u79FB", delay: "\u5EF6\u540E", remove: "\u79FB\u9664" };
function resolve(R, actsIn, rnd) {
  const acts = actsIn.map((a) => ({ ...a, done: false }));
  for (const a0 of contActs(R)) {
    a0.done = false;
    acts.push(a0);
  }
  R.conts = R.conts.filter((c) => (c.left -= 1) > 0);
  for (const a1 of acts) {
    const bl = a1.blood ?? 0;
    if (bl > 0) {
      R.U[a1.uid].hp -= bl;
      credit(R, a1.side, "blood", bl);
      ev(R, { t: 0, type: "blood", uid: a1.uid, amount: bl, ord: a1.ord });
    }
  }
  for (let t = 0; t <= TIMELINE; t++) {
    const firing = acts.filter((a) => !a.done && a.start === t);
    if (!firing.length) continue;
    firing.sort((x, y) => {
      const dx = x.def ? 0 : 1, dy = y.def ? 0 : 1;
      return dx !== dy ? dx - dy : x.ord - y.ord;
    });
    for (const a3 of firing) {
      if (a3.done || a3.start !== t) continue;
      a3.done = true;
      if (R.U[a3.uid].down !== -1) {
        fizzle(R, a3, t, "\u51FA\u624B\u7684\u968F\u4ECE\u5DF2\u7ECF\u5012\u4E0B");
        continue;
      }
      fire(R, a3, acts, rnd, t);
    }
    koCheck(R, rnd, t);
  }
  for (const a4 of acts) if (!a4.done) {
    a4.done = true;
    fizzle(R, a4, TIMELINE, "\u6CA1\u8D76\u4E0A");
  }
  for (const u2 of R.U) {
    if (u2.down !== -1) continue;
    const bu = u2.st["\u707C\u70E7"];
    if (bu) {
      const d = dmgTo(R, bu[2], u2, bu[0]);
      if (bu[2] !== u2.side) {
        const c = R.cls[bu[2]];
        if (c === "\u7EED") credit(R, bu[2], "cont", d);
        else if (c === "\u62E9") credit(R, bu[2], "pick", d);
      }
      ev(R, { t: TIMELINE + 1, type: "burn", tgt: u2.uid, amount: bu[0], dealt: d });
    }
  }
  koCheck(R, rnd, TIMELINE + 1);
  for (const a5 of actsIn) {
    const s = a5.side;
    if (R.cls[s] !== "\u5E76" || a5.cl.length < 2) continue;
    const kinds = /* @__PURE__ */ new Set();
    let landed = 0;
    a5.cl.forEach((c5, ci) => {
      if (R.eff[ekey(a5.ord, ci)]) {
        landed++;
        kinds.add(KIND_NAME[c5.k] ?? c5.k);
      }
    });
    const all = landed === a5.cl.length;
    const pts = landed + (all ? B_BONUS + B_LEN * Math.max(0, a5.cl.length - 2) : 0);
    if (pts > 0) {
      credit(R, s, "chain", pts);
      ev(R, { t: TIMELINE + 1, type: "chain", ord: a5.ord, uid: a5.uid, kinds: [...kinds], landed, points: pts, all });
    }
  }
}
function clauseWords(c) {
  switch (c.k) {
    case "st":
      return [c.st];
    case "redirect":
      return ["\u8F6C\u79FB"];
    case "delay":
      return ["\u5EF6\u540E"];
    case "remove":
      return ["\u79FB\u9664"];
  }
  return [];
}
var actionWords = (cls) => cls.flatMap(clauseWords);
var cnt = (c) => {
  const m = c.tmode ?? "choose";
  if (m === "self" || m === "pick") return 1;
  if (c.count !== void 0) return c.count;
  return (c.tg ?? []).length;
};
function actionNumbers(cls, freecount = false) {
  const out = [];
  for (const c of cls) {
    const n = freecount && c.tmode === "late" ? 1 : cnt(c);
    switch (c.k) {
      case "atk":
      case "heal":
        out.push(n, c.n, c.rep ?? 1);
        break;
      case "mit":
      case "st":
        out.push(n, c.n);
        break;
      case "redirect":
        out.push(n);
        break;
      case "delay":
        out.push(c.n);
        break;
    }
    if ((c.cont ?? 1) > 1) out.push(c.cont);
  }
  return out.filter((v) => v > 1);
}
function actionCost(cls, andCost = AND_COST) {
  let cost = BASE_COST + (cls.length - 1) * andCost;
  for (const w of actionWords(cls)) cost += WORDS[w].price;
  return cost;
}
var actionWindup = (cls, perClause = 1) => 1 + actionWords(cls).length + (cls.length - 1) * perClause;
var isDef = (cls) => cls.every((c) => ["mit", "redirect", "heal"].includes(c.k));
function clauseWord(c) {
  if (c.k === "st") return c.st;
  return { atk: "\u9020\u6210", heal: "\u6062\u590D", mit: "\u51CF\u4F24", redirect: "\u8F6C\u79FB", delay: "\u5EF6\u540E", remove: "\u79FB\u9664" }[c.k] ?? c.k;
}
var contCount = (cls) => cls.filter((c) => (c.cont ?? 1) > 1).length;
function wordRuleProblem(cls, cp) {
  if (cp.once) {
    const seen = /* @__PURE__ */ new Set();
    for (const c of cls) {
      const w = clauseWord(c);
      if (seen.has(w)) return `\u5E76\u6D41\uFF1A\u4E00\u53E5\u91CC\u3010${w}\u3011\u53EA\u80FD\u7528\u4E00\u6B21\uFF08\u6362\u4E00\u4E2A\u8BCD\u63A5\u4E0A\u53BB\uFF09`;
      seen.add(w);
    }
  }
  if (cp.cont_single && cls.length > 1 && contCount(cls) > 0) return "\u7EED\u6D41\uFF1A\u5E26\u3010\u6301\u7EED\u3011\u7684\u53E5\u5B50\u53EA\u80FD\u4E00\u6BB5\uFF0C\u4E0D\u80FD\u63A5\u3010\u5E76\u3011";
  if (cp.norep && cls.some((c) => (c.rep ?? 1) > 1)) return "\u62E9\u6D41\uFF1A\u53E5\u5B50\u91CC\u4E0D\u80FD\u7528\u3010\u91CD\u590D\u3011";
  return "";
}

// src/engine/ai.ts
var PASS_GAIN = 0.3;
var KO_LOOK = 0.5;
var DANGER_HP = 4;
var DANGER_W = 1;
var CONT_LOOK = 0.6;
var COMBO_K = 6;
var REP_MAX = 3;
function statValue(R, s) {
  let v = 0;
  for (const u of R.U) {
    if (u.down !== -1) continue;
    for (const nm in u.st) if (u.st[nm][2] === s) v += u.st[nm][0];
  }
  return v;
}
function contValue(R, s) {
  let v = 0;
  for (const c of R.conts) {
    if (c.side !== s) continue;
    const cl = c.cl;
    const cnt2 = cl.count ?? (cl.tg ?? [1]).length;
    v += (cl.n ?? 1) * Math.max(1, cnt2) * (cl.rep ?? 1) * c.left;
  }
  return v * CONT_LOOK;
}
function util(M, R, s) {
  const c0 = M.clsOf(s), c1 = M.clsOf(1 - s);
  const ps = prog(R, s, c0), po = prog(R, 1 - s, c1);
  let u = 100 * (ps - po);
  let hs = 0, ho = 0;
  for (const x of R.U) if (x.down === -1) {
    if (x.side === s) hs += x.hp;
    else ho += x.hp;
  }
  u += 0.8 * (hs - ho);
  u += 0.6 * (statValue(R, s) - statValue(R, 1 - s));
  const w0 = c0 === "\u7EED" ? 100 / TARGET[c0] : 0.5;
  const w1 = c1 === "\u7EED" ? 100 / TARGET[c1] : 0.5;
  u += contValue(R, s) * w0 - contValue(R, 1 - s) * w1;
  const kp = KO_PCT * 100 * KO_LOOK;
  for (const x2 of R.U) {
    if (x2.down !== -1) continue;
    const frac = 1 - x2.hp / x2.mx;
    const danger = Math.max(0, (DANGER_HP - x2.hp) / DANGER_HP) * DANGER_W;
    u += x2.side !== s ? kp * (frac + danger) : -kp * (frac + danger);
  }
  if (ps >= 1 || po >= 1) u += ps > po ? 500 : po > ps ? -500 : 0;
  return u;
}
var ids = (pool) => pool.map((u) => u.uid);
function tsets(pool, n, late) {
  if (late) return [null];
  const id = ids(pool);
  if (!id.length) return [];
  if (n >= id.length) return [id];
  if (n === 1) {
    const o = [[id[0]], [id[id.length - 1]]];
    if (id.length > 2) o.push([id[1]]);
    return o;
  }
  return [[id[0], id[1]], [id[0], id[id.length - 1]]];
}
function mkcl(k, side, tg, n, extra) {
  const d = { k, side, count: n };
  if (tg === null) {
    d.tmode = "late";
    d.tg = [];
  } else {
    d.tmode = "choose";
    d.tg = tg;
  }
  return Object.assign(d, extra);
}
function singles(M, s, cp) {
  const R = M.R;
  const late = !!cp.late;
  const E = [], F = [];
  for (const u of R.U) if (u.down === -1) (u.side !== s ? E : F).push(u);
  E.sort((a, b) => a.hp - b.hp);
  const vals = Object.keys(M.usableValues(s)).map(Number).sort((a, b) => b - a);
  const opts = [1];
  for (let i = 0; i < Math.min(2, vals.length); i++) opts.push(vals[i]);
  const copts = cp.freecount ? [1, 2, 3] : opts;
  const enemyActs = M.declared.filter((a) => a.side !== s);
  const thr = {};
  for (const a2 of enemyActs) for (const c of a2.cl) {
    if (c.k !== "atk") continue;
    if (c.tmode === "late") for (const u0 of F) thr[u0.uid] = (thr[u0.uid] ?? 0) + 1;
    for (const t of c.tg ?? []) thr[t] = (thr[t] ?? 0) + 1;
  }
  const fs = [...F].sort((a, b) => {
    const ta = thr[a.uid] ?? 0, tb = thr[b.uid] ?? 0;
    return ta !== tb ? tb - ta : a.hp - b.hp;
  });
  const threatOrder = ids(fs);
  const conts = [1];
  if (cp.slots > 0) {
    for (let i = 0; i < Math.min(2, vals.length); i++) if (vals[i] > 1) conts.push(vals[i]);
  }
  const words = M.res[s].words;
  const out = [];
  if (E.length) {
    for (const n of copts) {
      if (n > E.length) continue;
      for (const d of opts) {
        const reps = [1];
        if (!cp.norep && vals.length && vals[0] > 1 && vals[0] <= REP_MAX) reps.push(vals[0]);
        for (const r of reps) for (const tg of tsets(E, n, late)) for (const ct of conts)
          out.push([[mkcl("atk", "enemy", tg, n, { n: d, rep: r, cont: ct })], -1]);
      }
    }
  }
  const hurt = F.filter((u) => u.hp < u.mx).sort((a, b) => a.hp - a.mx - (b.hp - b.mx));
  if (hurt.length || cp.slots > 0) {
    for (const n2 of copts) {
      if (n2 > F.length) continue;
      for (const amt of opts) {
        const tg2 = [];
        for (const u4 of hurt) if (tg2.length < n2) tg2.push(u4.uid);
        for (const u5 of F) if (tg2.length < n2 && !tg2.includes(u5.uid)) tg2.push(u5.uid);
        for (const ct2 of conts) {
          if (!hurt.length && ct2 === 1) continue;
          out.push([[mkcl("heal", "ally", late ? null : tg2, n2, { n: amt, rep: 1, cont: ct2 })], -1]);
        }
      }
    }
  }
  if (enemyActs.length || cp.slots > 0 || cp.once) {
    for (const n3 of copts) {
      if (n3 > F.length) continue;
      for (const amt2 of opts) for (const ct3 of conts)
        out.push([[mkcl("mit", "ally", late ? null : threatOrder.slice(0, n3), n3, { n: amt2, cont: ct3 })], -1]);
    }
  }
  for (const nm of ENEMY_ST) {
    if ((words[nm] ?? 0) <= 0 || !E.length) continue;
    for (const n4 of copts) {
      if (n4 > E.length) continue;
      for (const dur of opts) for (const tg3 of tsets(E, n4, late))
        out.push([[mkcl("st", "enemy", tg3, n4, { st: nm, n: dur })], -1]);
    }
  }
  if ((words["\u8F6C\u79FB"] ?? 0) > 0 && (enemyActs.length || cp.once)) {
    for (const n5 of copts) {
      if (n5 > F.length) continue;
      out.push([[mkcl("redirect", "ally", late ? null : threatOrder.slice(0, n5), n5, {})], -1]);
    }
  }
  if ((words["\u5EF6\u540E"] ?? 0) > 0) {
    for (const a4 of enemyActs) for (const sec of opts)
      if (2 < a4.start) out.push([[{ k: "delay", act: a4.ord, n: sec, tg: [], side: "enemy", count: 1 }], 2]);
  }
  if ((words["\u79FB\u9664"] ?? 0) > 0) {
    for (const u7 of E) {
      const hasCont = R.conts.some((c3) => c3.uid === u7.uid);
      if (u7.lis.length || u7.mit > 0 || hasCont)
        out.push([[{ k: "remove", tg: [u7.uid], tmode: "pick", side: "enemy", count: 1 }], -1]);
    }
    for (const a5 of enemyActs) for (const c2 of a5.cl)
      if (["mit", "redirect"].includes(c2.k) && (c2.tg ?? []).length && a5.start + 1 <= TIMELINE)
        out.push([[{ k: "remove", tg: [c2.tg[0]], tmode: "pick", side: "enemy", count: 1 }], a5.start + 1]);
  }
  return out;
}
function make(M, s, uid, clList, start) {
  const ms = actionWindup(clList, M.caps(s).wind);
  const st = start < 0 ? ms : Math.max(start, ms);
  if (st > TIMELINE) return null;
  const r = M.buildAction(s, uid, clList, st);
  return r.err ? null : r.act;
}
var kindOf = (c) => c.k === "st" ? c.st : c.k;
function combos(n, k) {
  const out = [], cur = [];
  const rec = (i) => {
    if (cur.length === k) {
      out.push([...cur]);
      return;
    }
    for (let j = i; j < n; j++) {
      cur.push(j);
      rec(j + 1);
      cur.pop();
    }
  };
  rec(0);
  return out;
}
function candidates(M, s, uid, noise = true) {
  const R0 = M.R, cp = M.caps(s), cards = M.sides[s].cards;
  const enemyStarts = [];
  for (const a of M.declared) if (a.side !== s && !enemyStarts.includes(a.start)) enemyStarts.push(a.start);
  const evaluate = (act) => {
    act.ord = M.declared.length;
    const R2 = cloneR(R0);
    resolve(R2, [...M.declared, act], M.rnd);
    let v = util(M, R2, s) - 0.6 * act.cost;
    for (const i of act.cards) v -= (cards[i].once ? 0.5 : 0.25) * cards[i].v;
    return v + (noise ? M.rng.randf() * 0.3 : 0);
  };
  let local = [];
  for (const [cl, st] of singles(M, s, cp)) {
    const a = make(M, s, uid, cl, st);
    if (a) local.push([evaluate(a), a]);
  }
  local.sort((x, y) => y[0] - x[0]);
  if (cp.clauses >= 2) {
    const top = [], kinds = /* @__PURE__ */ new Set();
    for (const it of local) {
      const c0 = it[1].cl[0];
      if (c0.k === "delay" || kinds.has(kindOf(c0)) || top.length >= COMBO_K) continue;
      kinds.add(kindOf(c0));
      top.push(it[1]);
    }
    for (const it2 of local) {
      if (top.length >= COMBO_K) break;
      if (it2[1].cl[0].k === "delay" || top.includes(it2[1])) continue;
      top.push(it2[1]);
    }
    for (let size = 2; size <= Math.min(cp.clauses, top.length); size++) {
      for (const comb of combos(top.length, size)) {
        const clList = [];
        for (const idx of comb) for (const c1 of top[idx].cl) clList.push(structuredClone(c1));
        const a2 = make(M, s, uid, clList, -1);
        if (a2) local.push([evaluate(a2), a2]);
      }
    }
    const E = R0.U.filter((u) => u.side !== s && u.down === -1).sort((x, y) => x.hp - y.hp);
    if (E.length) {
      for (let kk = 2; kk <= cp.clauses; kk++) {
        const chain = [];
        for (let j = 0; j < kk; j++) chain.push(mkcl("atk", "enemy", cp.late ? null : [E[j % E.length].uid], 1, { n: 1, rep: 1 }));
        const a3 = make(M, s, uid, chain, -1);
        if (a3) local.push([evaluate(a3), a3]);
      }
    }
  }
  local.sort((x, y) => y[0] - x[0]);
  const extra = [];
  for (const it3 of local.slice(0, 4)) {
    const a4 = it3[1];
    if (a4.cl[0].k === "delay") continue;
    const sts = /* @__PURE__ */ new Set([a4.ms + 1]);
    for (const t of enemyStarts) {
      if (t >= a4.ms) sts.add(t);
      if (t - 1 >= a4.ms) sts.add(t - 1);
    }
    for (const st of sts) {
      if (st > TIMELINE || st === a4.start) continue;
      const b = { ...a4, start: st };
      extra.push([evaluate(b), b]);
    }
  }
  local = local.concat(extra);
  local.sort((x, y) => y[0] - x[0]);
  return local;
}
function baseUtil(M, s) {
  const R = cloneR(M.R);
  resolve(R, M.declared, M.rnd);
  return util(M, R, s);
}
function choose(M, s) {
  const u0 = baseUtil(M, s);
  let best = null, bestV = -1e9, worstUid = -1, worstGain = 1e9;
  for (const uid of M.remaining[s]) {
    const local = candidates(M, s, uid);
    const lb = local.length ? local[0][0] : -1e9;
    if (local.length && lb > bestV) {
      bestV = lb;
      best = local[0][1];
    }
    const g = lb - u0;
    if (g < worstGain) {
      worstGain = g;
      worstUid = uid;
    }
  }
  if (best === null || bestV - u0 < PASS_GAIN) return { uid: worstUid !== -1 ? worstUid : M.remaining[s][0], act: null };
  return { uid: best.uid, act: best };
}
function bestTargets(M, s, c) {
  const pool = M.R.U.filter((u) => u.down === -1 && u.side !== s === (c.side === "enemy")).map((u) => u.uid);
  const n = Math.min(c.count, pool.length);
  let best = [], bv = -1e9;
  for (const comb of combos(pool.length, n)) {
    const tg = comb.map((i) => pool[i]);
    c.tg = tg;
    const R2 = cloneR(M.R);
    resolve(R2, M.declared, M.rnd);
    const v = util(M, R2, s);
    if (v > bv) {
      bv = v;
      best = tg;
    }
  }
  return best;
}
function assignLate(M, s) {
  const order = M.declared.filter((a) => a.side === s).sort((x, y) => x.start !== y.start ? x.start - y.start : x.ord - y.ord);
  for (const a2 of order) for (const c of a2.cl) {
    if (c.tmode !== "late" || c.locked) continue;
    c.tg = bestTargets(M, s, c);
    c.locked = true;
  }
}
function suggestLate(M, s, ord, ci) {
  for (const a of M.declared) {
    if (a.ord !== ord) continue;
    const c = a.cl[ci], keep = [...c.tg ?? []];
    const best = bestTargets(M, s, c);
    c.tg = keep;
    return best;
  }
  return [];
}

// src/engine/match.ts
var Rng = class {
  a;
  constructor(seed) {
    this.a = seed >>> 0;
  }
  randf() {
    this.a = this.a + 1831565813 >>> 0;
    let t = this.a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  }
  int(lo, hi) {
    return lo + Math.floor(this.randf() * (hi - lo + 1));
  }
};
var Match = class {
  rng = new Rng(1);
  rnd = 0;
  first0 = 0;
  sides = [];
  R;
  human = [true, false];
  phase = "setup";
  declared = [];
  remaining = [[], []];
  passed = [[], []];
  turn = 0;
  res = [{}, {}];
  winner = -1;
  // -1 进行中；0/1；-2 平局
  lastEvents = [];
  roundNotes = [];
  lastDeclared = [];
  stats = [{}, {}];
  opts = {};
  start(d0, d1, seed = 1, human0 = true, human1 = false, opts = {}) {
    this.opts = opts;
    this.rng = new Rng(seed);
    this.human = [human0, human1];
    this.first0 = this.rng.int(0, 1);
    if (opts.first !== void 0) this.first0 = opts.first;
    this.rnd = 0;
    this.winner = -1;
    this.sides = [];
    this.stats = [{}, {}];
    const U = [];
    for (let s = 0; s < 2; s++) {
      const d = s === 0 ? d0 : d1;
      this.sides.push({ cls: d.cls, ap: opts.ap?.[s] ?? AP_START, deck: { ...d.words }, used: {}, prev: {}, cards: [], lad: [] });
      for (const v of opts.give?.[s] ?? []) this.sides[s].cards.push({ v, once: false, last: -9, src: "\u8D60" });
      for (let i = 0; i < 3; i++) {
        const perma = !!opts.perma?.includes(s * 3 + i);
        U.push({
          uid: s * 3 + i,
          side: s,
          name: opts.names?.[s]?.[i] ?? UNIT_NAMES[i],
          glyph: opts.glyphs?.[s]?.[i] ?? UNIT_GLYPHS[i],
          hp: perma ? 0 : d.hp[i],
          mx: d.hp[i],
          perma,
          down: perma ? 9999 : -1,
          st: {},
          kw: d.kws[i],
          kws: false,
          mit: 0,
          mitc: 0,
          shield: 0,
          msrc: [],
          lis: [],
          last: null
        });
      }
    }
    this.R = newR(U, [d0.cls, d1.cls]);
    this.beginRound();
  }
  clsOf(s) {
    return this.sides[s].cls;
  }
  progress(s) {
    return prog(this.R, s, this.clsOf(s));
  }
  caps(s) {
    return caps(this.clsOf(s), this.progress(s));
  }
  firstSide() {
    return (this.first0 + this.rnd - 1) % 2;
  }
  stat(s, key, v = 1) {
    this.stats[s][key] = (this.stats[s][key] ?? 0) + v;
  }
  contsOf(s) {
    return this.R.conts.filter((c) => c.side === s);
  }
  beginRound() {
    this.rnd++;
    for (const u of this.R.U) {
      u.mit = 0;
      u.mitc = 0;
      u.msrc = [];
      u.lis = [];
      u.kws = false;
      u.shield = 0;
      if (u.down !== -1 && !u.perma && this.rnd >= u.down + 2) {
        u.down = -1;
        u.hp = u.mx;
        u.st = {};
      } else if (u.down === -1) {
        for (const nm of Object.keys(u.st)) {
          const e = u.st[nm];
          if (this.rnd > e[1]) delete u.st[nm];
          else e[0] += 1;
        }
      }
    }
    this.roundNotes = [];
    for (let s = 0; s < 2; s++) {
      const sd = this.sides[s];
      if (this.rnd > 1) sd.ap = Math.min(sd.ap + AP_INCOME, AP_CAP);
      sd.prev = sd.used;
      sd.used = {};
      if (FLOOR[this.rnd]) {
        sd.cards.push({ v: FLOOR[this.rnd], once: false, last: -9, src: "\u4FDD\u5E95" });
        this.roundNotes.push({ side: s, type: "floor", value: FLOOR[this.rnd] });
      }
      this.res[s] = { ap: sd.ap, words: this.availWordsBase(s), cards: [], conts: 0 };
    }
    this.declared = [];
    this.passed = [[], []];
    this.remaining = [[], []];
    for (const u of this.R.U) if (u.down === -1) this.remaining[u.side].push(u.uid);
    this.turn = this.firstSide();
    this.phase = "declare";
  }
  availWordsBase(s) {
    const sd = this.sides[s], out = {};
    for (const w of WORD_ORDER) out[w] = (sd.deck[w] ?? 0) - (sd.prev[w] ?? 0);
    return out;
  }
  coolingWords(s) {
    return { ...this.sides[s].prev };
  }
  usableCards(s) {
    const out = [];
    const reserved = this.res[s].cards;
    this.sides[s].cards.forEach((c, i) => {
      if (reserved.includes(i)) return;
      if (c.once || this.rnd - c.last >= 2) out.push(i);
    });
    return out;
  }
  usableValues(s) {
    const out = {};
    for (const i of this.usableCards(s)) {
      const v = this.sides[s].cards[i].v;
      out[v] = (out[v] ?? 0) + 1;
    }
    return out;
  }
  pickCards(s, values) {
    const need = {};
    for (const v of values) if (v > 1) need[v] = (need[v] ?? 0) + 1;
    if (!Object.keys(need).length) return [];
    const avail = this.usableCards(s), cards = this.sides[s].cards, used = [];
    for (const vs of Object.keys(need)) {
      const v = +vs;
      const cand = avail.filter((i) => cards[i].v === v && !used.includes(i));
      cand.sort((a, b) => (cards[a].once ? 1 : 0) - (cards[b].once ? 1 : 0));
      if (cand.length < need[v]) return null;
      for (let k = 0; k < need[v]; k++) used.push(cand[k]);
    }
    return used;
  }
  bloodRoom(s, uid) {
    const cp = this.caps(s);
    if (cp.blood <= 0) return 0;
    return Math.max(0, Math.min(cp.blood, this.R.U[uid].hp - 1));
  }
  declareSide() {
    if (this.phase !== "declare") return -1;
    if (!this.remaining[0].length && !this.remaining[1].length) return -1;
    if (!this.remaining[this.turn].length) return 1 - this.turn;
    return this.turn;
  }
  publicDeclared(s) {
    return this.declared.filter((a) => a.side === s);
  }
  buildAction(s, uid, cls, start) {
    if (!cls.length) return { err: "\u8FD9\u53E5\u8BDD\u662F\u7A7A\u7684" };
    const cp = this.caps(s);
    if (cls.length > cp.clauses) return { err: `\u4E00\u53E5\u6700\u591A ${cp.clauses} \u6BB5` };
    const u = this.R.U[uid];
    if (u.side !== s || u.down !== -1) return { err: "\u8FD9\u4E2A\u968F\u4ECE\u73B0\u5728\u4E0D\u80FD\u51FA\u624B" };
    const rule = wordRuleProblem(cls, cp);
    if (rule) return { err: rule };
    const words = actionWords(cls);
    const need = {};
    for (const w of words) need[w] = (need[w] ?? 0) + 1;
    for (const w in need) if ((this.res[s].words[w] ?? 0) < need[w]) return { err: `\u3010${w}\u3011\u4E0D\u591F\u7528\uFF08\u5361\u7EC4\u91CC\u7684\u5F20\u6570\u7528\u5B8C\u4E86\uFF0C\u6216\u8005\u5728\u51B7\u5374\uFF09` };
    const cost = actionCost(cls, cp.and);
    let blood = 0;
    if (cost > this.res[s].ap) {
      blood = cost - this.res[s].ap;
      if (cp.blood <= 0) return { err: `\u884C\u52A8\u70B9\u4E0D\u591F\uFF08\u8981 ${cost}\uFF0C\u8FD8\u5269 ${this.res[s].ap}\uFF09` };
      if (blood > this.bloodRoom(s, uid)) return { err: `\u884C\u52A8\u70B9\u4E0D\u591F\uFF0C\u7528\u8840\u4E5F\u4ED8\u4E0D\u8D77\uFF08\u5DEE ${blood}\uFF0C\u8FD9\u4E2A\u968F\u4ECE\u6700\u591A\u80FD\u4ED8 ${this.bloodRoom(s, uid)} \u8840\uFF09` };
      for (const c0 of cls) {
        if (cp.noheal && c0.k === "heal") return { err: "\u7528\u8840\u4ED8\u7684\u53E5\u5B50\u91CC\u4E0D\u80FD\u6709\u3010\u6062\u590D\u3011" };
        if (cp.nodef && ["mit", "redirect"].includes(c0.k)) return { err: "\u7528\u8840\u4ED8\u7684\u53E5\u5B50\u91CC\u4E0D\u80FD\u6709\u3010\u51CF\u4F24\u3011\u3010\u8F6C\u79FB\u3011" };
      }
    }
    const nc = contCount(cls);
    if (nc > 0) {
      if (cp.slots <= 0) return { err: "\u53EA\u6709\u7EED\u6D41\u80FD\u628A\u3010\u6301\u7EED\u3011\u63A5\u5728\u4F24\u5BB3\u3001\u6062\u590D\u3001\u51CF\u4F24\u540E\u9762" };
      if (this.contsOf(s).length + this.res[s].conts + nc > cp.slots) return { err: `\u7EED\u6302\u6EE1\u4E86\uFF08\u540C\u65F6\u6700\u591A ${cp.slots} \u4E2A\uFF09` };
    }
    const nums = actionNumbers(cls, cp.freecount);
    const cards = this.pickCards(s, nums);
    if (cards === null) return { err: `\u6570\u5B57\u724C\u4E0D\u591F\uFF1A\u8FD9\u53E5\u8981\u7528 [${nums.join(", ")}]` };
    const ms = actionWindup(cls, cp.wind);
    if (start < ms) return { err: `\u8FD9\u53E5\u6700\u65E9\u7B2C ${ms} \u79D2\u624D\u80FD\u8D77\u6548` };
    if (start > TIMELINE) return { err: `\u65F6\u95F4\u8F74\u53EA\u6709 ${TIMELINE} \u79D2` };
    for (const c of cls) {
      if (c.tmode === "late") continue;
      for (const tid of c.tg ?? []) if (this.R.U[tid].down !== -1) return { err: "\u76EE\u6807\u5DF2\u7ECF\u5012\u4E0B\u4E86" };
      if (c.k === "delay" && !this.declared.some((b) => b.ord === c.act && b.side !== s)) return { err: "\u5EF6\u540E\u8981\u9009\u5BF9\u65B9\u5DF2\u7ECF\u5BA3\u544A\u7684\u4E00\u53E5" };
    }
    return { act: { side: s, uid, start, cl: cls, cost, blood, cards, words, def: isDef(cls), ms, cv: nums, ord: this.declared.length } };
  }
  submit(s, uid, act) {
    if (this.declareSide() !== s) return "\u8FD8\u6CA1\u8F6E\u5230\u4F60";
    if (!this.remaining[s].includes(uid)) return "\u8FD9\u4E2A\u968F\u4ECE\u8FD9\u4E00\u8F6E\u5DF2\u7ECF\u5B9A\u8FC7\u4E86";
    if (act) {
      act.ord = this.declared.length;
      this.declared.push(act);
      this.res[s].ap -= Math.min(act.cost, this.res[s].ap);
      for (const w of act.words) this.res[s].words[w] = (this.res[s].words[w] ?? 0) - 1;
      for (const i of act.cards) this.res[s].cards.push(i);
      this.res[s].conts += contCount(act.cl);
    } else this.passed[s].push(uid);
    this.remaining[s].splice(this.remaining[s].indexOf(uid), 1);
    this.turn = 1 - s;
    if (!this.remaining[0].length && !this.remaining[1].length) this.afterDeclare();
    return "";
  }
  pendingLate(s) {
    const out = [];
    for (const a of this.declared) {
      if (a.side !== s) continue;
      a.cl.forEach((c, ci) => {
        if (c.tmode === "late" && !c.locked) out.push({ ord: a.ord, ci, cl: c });
      });
    }
    return out;
  }
  afterDeclare() {
    for (let s = 0; s < 2; s++) if (!this.human[s] && this.clsOf(s) === "\u62E9") assignLate(this, s);
    for (let s = 0; s < 2; s++) if (this.human[s] && this.clsOf(s) === "\u62E9" && this.pendingLate(s).length) this.phase = "assign";
  }
  setLate(ord, ci, tg) {
    for (const a of this.declared) if (a.ord === ord) {
      a.cl[ci].tg = [...tg];
      a.cl[ci].locked = true;
    }
  }
  finishAssign() {
    if (this.phase === "assign") this.phase = "declare";
  }
  aiStep() {
    const s = this.declareSide();
    if (s === -1 || this.human[s]) return;
    const pick = choose(this, s);
    this.submit(s, pick.uid, pick.act);
  }
  resolveRound() {
    const R = this.R;
    R.kos = [0, 0];
    R.lost = [0, 0];
    R.fz = [0, 0];
    R.maxhit = 0;
    R.eff = {};
    R.retarget = [0, 0];
    R.ev = [];
    resolve(R, this.declared, this.rnd);
    this.lastEvents = R.ev;
    R.ev = null;
    this.lastDeclared = [...this.declared];
    const bloodPaid = [0, 0];
    for (const a of this.declared) {
      const s = a.side, sd = this.sides[s];
      sd.ap -= Math.min(a.cost, sd.ap);
      bloodPaid[s] += a.blood ?? 0;
      if ((a.blood ?? 0) > 0) {
        this.stat(s, "\u8840\u53E5");
        this.stat(s, "\u8840\u4ED8", a.blood);
      }
      if (contCount(a.cl) > 0) this.stat(s, "\u7EED\u53E5");
      if (a.cl.length > CLAUSE_MAX) this.stat(s, "\u8D85\u957F\u53E5");
      for (const c of a.cl) if (c.tmode === "late") this.stat(s, "\u5F85\u5B9A\u6BB5");
      for (const w of a.words) sd.used[w] = (sd.used[w] ?? 0) + 1;
      for (const i of a.cards) {
        const c2 = sd.cards[i];
        if (c2.once) c2.gone = true;
        else c2.last = this.rnd;
      }
    }
    for (let s = 0; s < 2; s++) if (R.retarget[s] > 0) this.stat(s, "\u62E9\u6362\u4EBA", R.retarget[s]);
    for (let s = 0; s < 2; s++) this.sides[s].cards = this.sides[s].cards.filter((c) => !c.gone);
    for (let s2 = 0; s2 < 2; s2++) {
      const sd2 = this.sides[s2];
      const lost = R.lost[s2] + (Y_DICE ? bloodPaid[s2] : 0);
      if (lost >= DICE_HP || R.kos[s2] > 0) {
        const rolls = [];
        for (let i = 0; i < DICE_COUNT; i++) {
          const v = this.rng.int(1, 6);
          rolls.push(v);
          if (v > 1) sd2.cards.push({ v, once: true, last: -9, src: "\u9AB0\u5B50" });
        }
        this.roundNotes.push({ side: s2, type: "dice", rolls, why: R.kos[s2] > 0 ? "\u6709\u968F\u4ECE\u5012\u4E0B" : `\u8FD9\u4E00\u8F6E\u6389\u4E86 ${lost} \u70B9\u8840` });
      }
      const p = this.progress(s2);
      LADDER.forEach((at, i) => {
        if (p >= at && !sd2.lad.includes(i)) {
          sd2.lad.push(i);
          for (let k = 0; k < LADDER_COPIES; k++) sd2.cards.push({ v: LADDER_VALUES[i], once: false, last: -9, src: "\u9636\u68AF" });
          this.roundNotes.push({ side: s2, type: "ladder", value: LADDER_VALUES[i], copies: LADDER_COPIES, at });
        }
      });
    }
    const p0 = this.progress(0), p1 = this.progress(1);
    if (this.opts.koWin) {
      const out = [0, 1].map((s) => this.R.U.filter((u) => u.side === s).every((u) => u.down !== -1));
      if (out[0] || out[1]) this.winner = out[0] && out[1] ? -2 : out[0] ? 1 : 0;
      else if (this.opts.maxRounds && this.rnd >= this.opts.maxRounds) this.winner = 1;
    } else if (p0 >= 1 || p1 >= 1 || this.rnd >= MAX_ROUNDS) this.winner = p0 > p1 ? 0 : p1 > p0 ? 1 : -2;
    this.phase = this.winner !== -1 ? "over" : "resolved";
    return this.lastEvents;
  }
  nextRound() {
    if (this.phase === "resolved") this.beginRound();
  }
  runToEnd(maxSteps = 2e3) {
    let n = 0;
    while (this.phase !== "over" && n++ < maxSteps) {
      if (this.phase === "declare") {
        const s = this.declareSide();
        if (s === -1) this.resolveRound();
        else {
          const pick = choose(this, s);
          this.submit(s, pick.uid, pick.act);
        }
      } else if (this.phase === "assign") {
        for (let s2 = 0; s2 < 2; s2++) if (this.clsOf(s2) === "\u62E9") assignLate(this, s2);
        this.finishAssign();
      } else if (this.phase === "resolved") this.nextRound();
    }
  }
};

// shared/view.ts
var copy = (x) => JSON.parse(JSON.stringify(x));
function pubAct(a, viewer, reveal, lockQ) {
  const cl = copy(a.cl).map((c) => {
    delete c.locked;
    return c;
  });
  const q = lockQ?.[a.ord];
  for (const c of cl) {
    if (c.tmode !== "late") continue;
    if (reveal) {
      c.shown = true;
      if (!(c.tg ?? []).length && q?.length) c.tg = q.shift();
    } else if (a.side !== viewer) {
      c.tg = [];
      c.hidden = true;
    }
  }
  return { ord: a.ord, side: a.side, uid: a.uid, start: a.start, cl, cost: a.cost, blood: a.blood ?? 0, words: [...a.words], def: !!a.def, ms: a.ms };
}
function viewFor(M, side, meta, events) {
  const reveal = M.phase === "resolved" || M.phase === "over";
  const lockQ = {};
  if (reveal && events) {
    for (const e of events) if (e.type === "lock") (lockQ[e.ord] ??= []).push([...e.tgts]);
  }
  const src = reveal ? M.lastDeclared : M.declared;
  const acts = src.map((a) => pubAct(a, side, reveal, lockQ));
  const units = M.R.U.map((u) => ({
    uid: u.uid,
    side: u.side,
    name: u.name,
    glyph: u.glyph,
    hp: u.hp,
    mx: u.mx,
    down: u.down,
    st: copy(u.st),
    kw: u.kw,
    kws: !!u.kws,
    mit: u.mit
  }));
  const sides = [0, 1].map((s) => ({
    name: meta.names[s],
    cls: M.clsOf(s),
    ap: M.res[s].ap ?? M.sides[s].ap,
    prog: M.progress(s),
    cardCount: M.sides[s].cards.length,
    connected: meta.connected[s],
    ready: meta.ready[s],
    metric: M.R.M[s][METRIC[M.clsOf(s)]],
    kob: M.R.kob[s]
  }));
  const usable = new Set(M.usableCards(side));
  const pending = [];
  if (M.phase === "assign") {
    for (const a of M.declared) {
      if (a.side !== side) continue;
      a.cl.forEach((c, ci) => {
        if (c.tmode === "late") pending.push({ ord: a.ord, ci, k: c.k, side: c.side ?? "enemy", count: c.count ?? 1, targets: [...c.tg ?? []], locked: !!c.locked });
      });
    }
  }
  const notes = reveal ? M.roundNotes.slice(meta.noteSplit) : M.roundNotes.slice(0, meta.noteSplit);
  return {
    phase: M.phase,
    rev: meta.rev,
    room: meta.room,
    you: side,
    round: M.rnd,
    turn: M.phase === "declare" ? M.declareSide() : -1,
    first: M.firstSide(),
    winner: M.winner,
    units,
    sides,
    remaining: [[...M.remaining[0]], [...M.remaining[1]]],
    acts,
    conts: M.R.conts.map((c) => ({ side: c.side, uid: c.uid, cl: copy(c.cl), left: c.left, start: c.start })),
    notes: copy(notes),
    me: {
      ap: M.res[side].ap,
      words: { ...M.res[side].words },
      cooling: M.coolingWords(side),
      cards: M.sides[side].cards.map((c, i) => ({ i, v: c.v, once: !!c.once, src: c.src, usable: usable.has(i) && !M.res[side].cards.includes(i), last: c.last ?? -9, reserved: M.res[side].cards.includes(i) })),
      caps: M.caps(side),
      pending,
      assignDone: meta.assignDone[side]
    },
    oppAssignDone: meta.assignDone[1 - side],
    deadline: meta.deadline
  };
}

// server/sanitize.ts
var KINDS = ["atk", "heal", "mit", "st", "redirect", "delay", "remove"];
var SIDES = { atk: ["enemy", "ally"], heal: ["ally"], mit: ["ally"], st: ["enemy"], redirect: ["ally"], delay: ["enemy"], remove: ["enemy"] };
var isInt = (x, lo, hi) => Number.isInteger(x) && x >= lo && x <= hi;
function sanitizeClauses(M, s, raw, cp, uid = -1) {
  if (!Array.isArray(raw) || raw.length < 1 || raw.length > 12) return { err: "\u53E5\u5B50\u683C\u5F0F\u4E0D\u5BF9" };
  const out = [];
  for (const r of raw) {
    if (!r || typeof r !== "object") return { err: "\u53E5\u5B50\u683C\u5F0F\u4E0D\u5BF9" };
    const k = r.k;
    if (!KINDS.includes(k)) return { err: `\u4E0D\u8BA4\u8BC6\u7684\u8BCD\u7C7B\u578B ${String(k).slice(0, 8)}` };
    const okSides = SIDES[k];
    const side = r.side === void 0 ? okSides[0] : r.side;
    if (!okSides.includes(side)) return { err: "\u76EE\u6807\u9635\u8425\u548C\u8FD9\u4E2A\u8BCD\u5BF9\u4E0D\u4E0A" };
    const c = { k, side };
    let tmode = r.tmode ?? "choose";
    if (!["choose", "pick", "late", "self"].includes(tmode)) return { err: "\u4E0D\u8BA4\u8BC6\u7684\u9009\u76EE\u6807\u65B9\u5F0F" };
    if (k === "remove") tmode = "pick";
    if (tmode === "pick" && k !== "remove") return { err: "\u53EA\u6709\u3010\u79FB\u9664\u3011\u80FD\u7528\u5355\u9009\u76EE\u6807" };
    if (tmode === "late" && !cp.late) return { err: "\u53EA\u6709\u62E9\u6D41\u80FD\u628A\u76EE\u6807\u7559\u5230\u5BA3\u544A\u5B8C\u518D\u5B9A" };
    if (tmode === "late" && ["delay", "remove"].includes(k)) return { err: "\u8FD9\u4E2A\u8BCD\u4E0D\u80FD\u5F85\u5B9A\u76EE\u6807" };
    if (tmode === "self" && (side !== "ally" || k === "delay")) return { err: "\u3010\u81EA\u8EAB\u3011\u53EA\u80FD\u7528\u5728\u5DF1\u65B9\u7684\u8BCD\u4E0A" };
    c.tmode = tmode;
    const pool = M.R.U.filter((u) => u.side !== s === (side === "enemy"));
    if (k === "delay") {
      if (!isInt(r.act, 0, 999)) return { err: "\u5EF6\u540E\u8981\u9009\u5BF9\u65B9\u5DF2\u5BA3\u544A\u7684\u4E00\u53E5" };
      c.act = r.act;
      c.tg = [];
      c.count = 1;
      c.tmode = "choose";
    } else if (tmode === "self") {
      if (!isInt(uid, 0, 5) || M.R.U[uid]?.side !== s) return { err: "\u81EA\u8EAB\u6307\u5411\u7684\u968F\u4ECE\u4E0D\u5BF9" };
      c.tg = [uid];
      c.count = 1;
    } else if (tmode === "late") {
      if (!isInt(r.count, 1, pool.length)) return { err: "\u76EE\u6807\u4E2A\u6570\u4E0D\u5BF9" };
      c.count = r.count;
      c.tg = [];
    } else {
      const tg = r.tg;
      if (!Array.isArray(tg) || !tg.every((x) => isInt(x, 0, 5)) || new Set(tg).size !== tg.length) return { err: "\u76EE\u6807\u4E0D\u5BF9" };
      if (!tg.every((x) => pool.some((u) => u.uid === x))) return { err: "\u76EE\u6807\u9635\u8425\u4E0D\u5BF9" };
      const want = tmode === "pick" ? 1 : tg.length;
      if (tg.length !== want || want < 1) return { err: "\u76EE\u6807\u4E2A\u6570\u4E0D\u5BF9" };
      c.tg = [...tg];
      c.count = tg.length;
    }
    if (k === "atk" || k === "heal") {
      if (!isInt(r.n, 1, 6) || !isInt(r.rep ?? 1, 1, 6)) return { err: "\u6570\u5B57\u4E0D\u5BF9" };
      c.n = r.n;
      c.rep = r.rep ?? 1;
    } else if (k === "mit") {
      if (!isInt(r.n, 1, 6)) return { err: "\u6570\u5B57\u4E0D\u5BF9" };
      c.n = r.n;
    } else if (k === "st") {
      if (WORDS[r.st]?.kind !== "status" || !isInt(r.n, 1, 6)) return { err: "\u72B6\u6001\u8BCD\u4E0D\u5BF9" };
      c.st = r.st;
      c.n = r.n;
    } else if (k === "delay") {
      if (!isInt(r.n, 1, 6)) return { err: "\u6570\u5B57\u4E0D\u5BF9" };
      c.n = r.n;
    }
    if (r.cont !== void 0) {
      if (!isInt(r.cont, 1, 6)) return { err: "\u6301\u7EED\u8F6E\u6570\u4E0D\u5BF9" };
      if (r.cont > 1) {
        if (!["atk", "heal", "mit"].includes(k)) return { err: "\u3010\u6301\u7EED\u3011\u53EA\u80FD\u63A5\u5728\u4F24\u5BB3\u3001\u6062\u590D\u3001\u51CF\u4F24\u540E\u9762" };
        c.cont = r.cont;
      }
    }
    out.push(c);
  }
  return { cls: out };
}

// server/room.ts
var ASSIGN_MS = +(process.env.ASSIGN_MS ?? 9e4);
var NEXT_MS = +(process.env.NEXT_MS ?? 3e4);
var reconnectMs = () => +(process.env.RECONNECT_MS ?? 9e4);
var RoomError = class extends Error {
  constructor(code, msg) {
    super(msg);
    this.code = code;
  }
};
var fail = (code, msg) => {
  throw new RoomError(code, msg);
};
function deckFromSpec(d) {
  const cls = d?.cls ?? "\u5E76";
  if (!CLASSES.includes(cls)) return fail("bad_deck", "\u6CA1\u6709\u8FD9\u4E2A\u6D41\u6D3E");
  const base = presetDeck(cls);
  if (d && (d.words || d.kws || d.hp)) {
    const words = d.words ?? base.words, kws = d.kws ?? base.kws, hp = d.hp ?? base.hp;
    if (typeof words !== "object" || !Array.isArray(kws) || !Array.isArray(hp)) return fail("bad_deck", "\u5361\u7EC4\u683C\u5F0F\u4E0D\u5BF9");
    for (const w in words) if (!Number.isInteger(words[w]) || words[w] < 0) return fail("bad_deck", "\u5361\u7EC4\u5F20\u6570\u4E0D\u5BF9");
    if (!hp.every((x) => Number.isInteger(x))) return fail("bad_deck", "\u751F\u547D\u5206\u914D\u4E0D\u5BF9");
    const p = deckProblem(words, kws) || hpProblem(hp);
    if (p) fail("bad_deck", p);
    return { cls, words: { ...words }, kws: [...kws], hp: [...hp] };
  }
  return base;
}
var Room = class {
  constructor(id) {
    this.id = id;
  }
  players = [null, null];
  M = null;
  rev = 0;
  assignDone = [false, false];
  nextReady = [false, false];
  deadline = 0;
  noteSplit = 0;
  lastEvents = [];
  timer = null;
  seed = 0;
  created = Date.now();
  get playing() {
    return !!this.M;
  }
  idleMs() {
    return Date.now() - Math.max(this.created, ...this.players.map((p) => p?.lastSeen ?? 0));
  }
  anyConnected() {
    return this.players.some((p) => p?.ws);
  }
  connected() {
    return this.players.map((p) => !!p?.ws && !p.left);
  }
  meta() {
    const inRound = this.M && (this.M.phase === "resolved" || this.M.phase === "over");
    return {
      room: this.id,
      rev: this.rev,
      names: this.players.map((p) => p?.name ?? "?"),
      connected: this.connected(),
      ready: inRound ? [...this.nextReady] : this.players.map((p) => !!p?.ready),
      assignDone: [...this.assignDone],
      deadline: this.deadline,
      noteSplit: this.noteSplit
    };
  }
  viewOf(side) {
    if (!this.M) {
      const v = {
        phase: "lobby",
        rev: this.rev,
        room: this.id,
        you: side,
        players: this.players.map((p) => p ? { name: p.name, cls: p.deck.cls, ready: p.ready, connected: !!p.ws && !p.left } : null)
      };
      return v;
    }
    return viewFor(this.M, side, this.meta(), this.lastEvents);
  }
  send(side, m) {
    const ws = this.players[side]?.ws;
    if (ws && ws.readyState === 1) ws.send(JSON.stringify(m));
  }
  /** 递增 rev 并向双方发各自视角的快照；传入 events 则发 resolved（一次性揭示） */
  broadcast(resolvedEvents) {
    this.rev++;
    for (let s = 0; s < 2; s++) {
      if (resolvedEvents) this.send(s, { t: "resolved", rev: this.rev, events: resolvedEvents, view: this.viewOf(s) });
      else this.send(s, { t: "state", rev: this.rev, view: this.viewOf(s) });
    }
  }
  // ---------- 入退房 ----------
  join(ws, name, deck) {
    if (this.playing) fail("full", "\u8FD9\u4E2A\u623F\u95F4\u5DF2\u7ECF\u5728\u6253\u4E86\uFF08\u65AD\u7EBF\u7684\u4EBA\u8BF7\u7528\u91CD\u8FDE\uFF09");
    const side = !this.players[0] ? 0 : !this.players[1] ? 1 : -1;
    if (side < 0) return fail("full", "\u623F\u95F4\u5DF2\u6EE1");
    const nm = String(name || "").trim().slice(0, 12) || `\u73A9\u5BB6${side + 1}`;
    const p = { name: nm, token: randomBytes(16).toString("hex"), deck: deckFromSpec(deck), ws, ready: false, lastSeen: Date.now(), left: false, dc: null };
    this.players[side] = p;
    this.send(side, { t: "joined", side, token: p.token, room: this.id });
    this.send(1 - side, { t: "peer", status: "joined", name: p.name });
    this.broadcast();
    return side;
  }
  rejoin(ws, token) {
    const side = this.players.findIndex((p2) => p2 && p2.token === token);
    if (side < 0) return fail("bad_token", "\u91CD\u8FDE\u51ED\u8BC1\u4E0D\u5BF9");
    const p = this.players[side];
    if (p.left) return fail("bad_token", "\u4F60\u5DF2\u7ECF\u79BB\u5F00\u4E86\u8FD9\u4E00\u5C40");
    if (p.dc) {
      clearTimeout(p.dc);
      p.dc = null;
    }
    if (p.ws && p.ws !== ws) {
      try {
        p.ws.close(4e3, "replaced");
      } catch {
      }
    }
    p.ws = ws;
    p.lastSeen = Date.now();
    this.send(side, { t: "joined", side, token: p.token, room: this.id });
    this.send(1 - side, { t: "peer", status: "back", name: p.name });
    this.broadcast();
    return side;
  }
  disconnect(ws) {
    const side = this.players.findIndex((p2) => p2 && p2.ws === ws);
    if (side < 0) return;
    const p = this.players[side];
    p.ws = null;
    p.lastSeen = Date.now();
    if (!this.playing) this.players[side] = null;
    else if (this.M.phase !== "over" && !p.left) {
      if (p.dc) clearTimeout(p.dc);
      p.dc = setTimeout(() => {
        p.dc = null;
        if (!p.ws) this.forfeit(side);
      }, reconnectMs());
    }
    this.send(1 - side, { t: "peer", status: "left", name: p.name });
    this.broadcast();
  }
  /** 两个人都进来之后直接开打（匹配队列用，不需要再点准备） */
  begin() {
    if (this.playing || !this.players[0] || !this.players[1]) return;
    this.startGame();
  }
  /** 主动离开：对局进行中视为认输；对局结束/大厅里就是单纯走人 */
  leave(ws) {
    const side = this.players.findIndex((p2) => p2 && p2.ws === ws);
    if (side < 0) return;
    const p = this.players[side];
    if (!this.playing) {
      this.disconnect(ws);
      return;
    }
    if (this.M.phase !== "over") this.forfeit(side);
    p.left = true;
    p.ws = null;
    if (p.dc) {
      clearTimeout(p.dc);
      p.dc = null;
    }
    this.send(1 - side, { t: "peer", status: "left", name: p.name, quit: true });
    this.broadcast();
  }
  /** 认输（主动退出、或掉线超时）：对手获胜，对局进入 over */
  forfeit(side) {
    const M = this.M;
    if (!M || M.phase === "over") return;
    this.clearTimer();
    M.winner = 1 - side;
    M.phase = "over";
    this.lastEvents = [];
    this.nextReady = [false, false];
    this.noteSplit = M.roundNotes.length;
    this.broadcast();
  }
  // ---------- 处理客户端意图（非法的抛 RoomError，不改状态） ----------
  handle(side, m) {
    this.players[side].lastSeen = Date.now();
    switch (m.t) {
      case "ready":
        return this.onReady(side);
      case "declare":
        return this.onDeclare(side, m.uid, m.cls, m.start);
      case "pass":
        return this.onPass(side, m.uid);
      case "assign_late":
        return this.onAssign(side, m.ord, m.ci, m.targets);
      case "confirm_assign":
        return this.onConfirm(side);
    }
  }
  game() {
    return this.M ?? fail("phase", "\u5BF9\u5C40\u8FD8\u6CA1\u5F00\u59CB");
  }
  onReady(side) {
    if (!this.M) {
      this.players[side].ready = true;
      if (this.players[0]?.ready && this.players[1]?.ready) this.startGame();
      else this.broadcast();
      return;
    }
    const ph = this.M.phase;
    if (ph !== "resolved" && ph !== "over") fail("phase", "\u73B0\u5728\u4E0D\u7528\u51C6\u5907");
    this.nextReady[side] = true;
    if (this.nextReady[0] && this.nextReady[1]) {
      if (ph === "over") this.startGame();
      else this.nextRound();
    } else this.broadcast();
  }
  startGame() {
    this.clearTimer();
    this.seed = randomInt(1, 2 ** 31 - 1);
    const M = new Match();
    M.start(this.players[0].deck, this.players[1].deck, this.seed, true, true);
    this.M = M;
    this.resetRound();
    this.broadcast();
  }
  resetRound() {
    this.noteSplit = this.M.roundNotes.length;
    this.assignDone = [false, false];
    this.nextReady = [false, false];
    this.lastEvents = [];
  }
  nextRound() {
    this.clearTimer();
    this.M.nextRound();
    this.resetRound();
    this.broadcast();
  }
  onDeclare(s, uid, cls, start) {
    const M = this.game();
    if (M.phase !== "declare") fail("phase", "\u73B0\u5728\u4E0D\u662F\u5BA3\u544A\u9636\u6BB5");
    if (M.declareSide() !== s) fail("turn", "\u8FD8\u6CA1\u8F6E\u5230\u4F60");
    if (!Number.isInteger(uid) || uid < 0 || uid > 5) fail("bad_unit", "\u968F\u4ECE\u4E0D\u5BF9");
    if (!M.remaining[s].includes(uid)) fail("bad_unit", "\u8FD9\u4E2A\u968F\u4ECE\u8FD9\u4E00\u8F6E\u5DF2\u7ECF\u5B9A\u8FC7\u4E86");
    if (!Number.isInteger(start)) fail("bad_start", "\u8D77\u624B\u79D2\u6570\u4E0D\u5BF9");
    const sc = sanitizeClauses(M, s, cls, M.caps(s), uid);
    if (sc.err) fail("bad_act", sc.err);
    const r = M.buildAction(s, uid, sc.cls, start);
    if (r.err || !r.act) return fail("rule", r.err ?? "\u4E0D\u884C");
    const e = M.submit(s, uid, r.act);
    if (e) fail("rule", e);
    this.advance();
  }
  onPass(s, uid) {
    const M = this.game();
    if (M.phase !== "declare") fail("phase", "\u73B0\u5728\u4E0D\u662F\u5BA3\u544A\u9636\u6BB5");
    if (M.declareSide() !== s) fail("turn", "\u8FD8\u6CA1\u8F6E\u5230\u4F60");
    if (!Number.isInteger(uid) || !M.remaining[s].includes(uid)) fail("bad_unit", "\u8FD9\u4E2A\u968F\u4ECE\u8FD9\u4E00\u8F6E\u5DF2\u7ECF\u5B9A\u8FC7\u4E86");
    const e = M.submit(s, uid, null);
    if (e) fail("rule", e);
    this.advance();
  }
  lateClauses(s) {
    const out = [];
    for (const a of this.M.declared) if (a.side === s) a.cl.forEach((c, ci) => {
      if (c.tmode === "late") out.push({ a, ci, c });
    });
    return out;
  }
  onAssign(s, ord, ci, targets) {
    const M = this.game();
    if (M.phase !== "assign") fail("phase", "\u73B0\u5728\u4E0D\u662F\u5B9A\u76EE\u6807\u9636\u6BB5");
    if (this.assignDone[s]) fail("done", "\u4F60\u5DF2\u7ECF\u786E\u8BA4\u8FC7\u4E86");
    const hit2 = this.lateClauses(s).find((x) => x.a.ord === ord && x.ci === ci);
    if (!hit2) return fail("bad_clause", "\u6CA1\u6709\u8FD9\u6BB5\u5F85\u5B9A\u76EE\u6807\uFF08\u6216\u8005\u4E0D\u662F\u4F60\u7684\uFF09");
    if (!Array.isArray(targets) || !targets.every((x) => Number.isInteger(x) && x >= 0 && x <= 5) || new Set(targets).size !== targets.length) fail("bad_target", "\u76EE\u6807\u4E0D\u5BF9");
    const wantEnemy = (hit2.c.side ?? "enemy") === "enemy";
    const pool = M.R.U.filter((u) => u.down === -1 && u.side !== s === wantEnemy);
    const need = Math.min(hit2.c.count ?? 1, pool.length);
    if (targets.length !== need) fail("bad_target", `\u8981\u9009 ${need} \u4E2A\u76EE\u6807`);
    if (!targets.every((x) => pool.some((u) => u.uid === x))) fail("bad_target", "\u76EE\u6807\u9635\u8425\u4E0D\u5BF9\u6216\u5DF2\u5012\u4E0B");
    M.setLate(ord, ci, targets);
    this.rev++;
    const ws = this.players[s]?.ws;
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: "state", rev: this.rev, view: this.viewOf(s) }));
  }
  onConfirm(s) {
    const M = this.game();
    if (M.phase !== "assign") fail("phase", "\u73B0\u5728\u4E0D\u662F\u5B9A\u76EE\u6807\u9636\u6BB5");
    if (this.assignDone[s]) fail("done", "\u4F60\u5DF2\u7ECF\u786E\u8BA4\u8FC7\u4E86");
    this.finishSide(s);
    this.advance();
  }
  /** 没填的待定段自动补上建议目标，然后标记该方已确认 */
  finishSide(s) {
    const M = this.M;
    for (const { a, ci, c } of this.lateClauses(s)) {
      if (!c.locked) M.setLate(a.ord, ci, suggestLate(M, s, a.ord, ci));
    }
    this.assignDone[s] = true;
  }
  // ---------- 推进 ----------
  advance() {
    const M = this.M;
    if (M.phase === "assign") {
      for (let s = 0; s < 2; s++) if (!this.assignDone[s] && !this.lateClauses(s).length) this.assignDone[s] = true;
      if (this.assignDone[0] && this.assignDone[1]) M.finishAssign();
      else if (!this.timer) this.armTimer(ASSIGN_MS, () => this.timeoutAssign());
    }
    if (M.phase === "declare" && M.declareSide() === -1) {
      this.clearTimer();
      this.noteSplit = M.roundNotes.length;
      const ev2 = M.resolveRound();
      this.lastEvents = ev2;
      this.nextReady = [false, false];
      if (M.phase === "resolved") this.armTimer(NEXT_MS, () => this.timeoutNext());
      this.broadcast(ev2);
      return;
    }
    this.broadcast();
  }
  timeoutAssign() {
    if (this.M?.phase !== "assign") return;
    for (let s = 0; s < 2; s++) if (!this.assignDone[s]) this.finishSide(s);
    this.advance();
  }
  timeoutNext() {
    if (this.M?.phase === "resolved") this.nextRound();
  }
  armTimer(ms, f) {
    this.clearTimer();
    this.deadline = Date.now() + ms;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.deadline = 0;
      try {
        f();
      } catch (e) {
        console.error(e);
      }
    }, ms);
  }
  clearTimer() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.deadline = 0;
  }
  dispose() {
    this.clearTimer();
    for (const p of this.players) if (p?.dc) {
      clearTimeout(p.dc);
      p.dc = null;
    }
  }
};

// server/index.ts
import { randomBytes as randomBytes2 } from "node:crypto";
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff2": "font/woff2",
  ".txt": "text/plain; charset=utf-8",
  ".map": "application/json"
};
var MAX_PAYLOAD = 16 * 1024;
var HELLO = "cizhan-lan";
var ROOM_IDLE_MS = 30 * 6e4;
var rate = () => +(process.env.RATE_PER_SEC ?? 10);
function startServer(opts = {}) {
  const dist = resolve2(opts.dist ?? join(fileURLToPath(new URL(".", import.meta.url)), "..", "dist"));
  const rooms = /* @__PURE__ */ new Map();
  const waiting = [];
  const dequeue = (conn) => {
    const i = waiting.findIndex((w) => w.conn === conn);
    if (i >= 0) waiting.splice(i, 1);
    return i >= 0;
  };
  const newRoomId = () => {
    let id;
    do {
      id = "M" + randomBytes2(3).toString("hex").toUpperCase();
    } while (rooms.has(id));
    return id;
  };
  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? "/", "http://x");
      if (url.pathname === "/__cizhan") {
        res.writeHead(200, { "content-type": "text/plain" }).end(HELLO);
        return;
      }
      let p = decodeURIComponent(url.pathname);
      if (p === "/" || p === "") p = "/index.html";
      const full = normalize(join(dist, p));
      if (full !== dist && !full.startsWith(dist + sep)) {
        res.writeHead(403).end("forbidden");
        return;
      }
      const st = await stat(full).catch(() => null);
      if (!st || !st.isFile()) {
        res.writeHead(404, { "content-type": "text/plain; charset=utf-8" }).end("\u6CA1\u6709\u8FD9\u4E2A\u6587\u4EF6\uFF08\u5148 npm run build\uFF1F\uFF09");
        return;
      }
      res.writeHead(200, { "content-type": MIME[extname(full)] ?? "application/octet-stream", "cache-control": "no-cache" });
      res.end(await readFile(full));
    } catch {
      res.writeHead(500).end("error");
    }
  });
  const wss = new import_websocket_server.default({ noServer: true, maxPayload: MAX_PAYLOAD });
  server.on("upgrade", (req, socket, head) => {
    if ((req.url ?? "").split("?")[0] !== "/ws") {
      socket.destroy();
      return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit("connection", ws, req));
  });
  const normRoom = (r) => String(r ?? "").trim().toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, 12);
  wss.on("connection", (ws) => {
    const conn = { room: null, side: -1, bucket: 30, stamp: Date.now(), ws };
    const send = (m) => {
      if (ws.readyState === 1) ws.send(JSON.stringify(m));
    };
    const err = (code, msg, seq) => send({ t: "err", code, msg, seq });
    ws.on("message", (data) => {
      const now = Date.now();
      conn.bucket = Math.min(30, conn.bucket + (now - conn.stamp) / 1e3 * rate());
      conn.stamp = now;
      if (conn.bucket < 1) return err("rate", "\u64CD\u4F5C\u592A\u5FEB\u4E86");
      conn.bucket--;
      let m;
      try {
        m = JSON.parse(data.toString());
      } catch {
        return err("bad_json", "\u6D88\u606F\u4E0D\u662F\u5408\u6CD5 JSON");
      }
      if (!m || typeof m !== "object" || typeof m.t !== "string") return err("bad_msg", "\u6D88\u606F\u683C\u5F0F\u4E0D\u5BF9");
      const seq = Number.isInteger(m.seq) ? m.seq : void 0;
      try {
        switch (m.t) {
          case "ping":
            return send({ t: "pong", seq });
          case "join": {
            if (conn.room) return err("already", "\u4F60\u5DF2\u7ECF\u5728\u4E00\u4E2A\u623F\u95F4\u91CC\u4E86", seq);
            const id = normRoom(m.room);
            if (!id) return err("bad_room", "\u623F\u95F4\u53F7\u4E0D\u80FD\u4E3A\u7A7A", seq);
            let room = rooms.get(id);
            const fresh = !room;
            if (!room) {
              room = new Room(id);
            }
            conn.side = room.join(ws, m.name, m.deck);
            if (fresh) rooms.set(id, room);
            conn.room = room;
            return;
          }
          case "rejoin": {
            if (conn.room) return err("already", "\u4F60\u5DF2\u7ECF\u5728\u4E00\u4E2A\u623F\u95F4\u91CC\u4E86", seq);
            const room = rooms.get(normRoom(m.room));
            if (!room) return err("no_room", "\u623F\u95F4\u4E0D\u5B58\u5728\uFF08\u670D\u52A1\u5668\u53EF\u80FD\u91CD\u542F\u8FC7\uFF09", seq);
            if (typeof m.token !== "string") return err("bad_token", "\u91CD\u8FDE\u51ED\u8BC1\u4E0D\u5BF9", seq);
            conn.side = room.rejoin(ws, m.token);
            conn.room = room;
            return;
          }
          case "queue": {
            if (conn.room) return err("already", "\u4F60\u5DF2\u7ECF\u5728\u4E00\u5C40\u91CC\u4E86", seq);
            deckFromSpec(m.deck);
            if (waiting.some((w) => w.conn === conn)) return send({ t: "queued", size: waiting.length });
            for (let i = waiting.length - 1; i >= 0; i--) if (waiting[i].ws.readyState !== 1) waiting.splice(i, 1);
            const other = waiting.shift();
            if (!other) {
              waiting.push({ conn, ws, name: m.name, deck: m.deck, since: Date.now() });
              return send({ t: "queued", size: waiting.length });
            }
            const room = new Room(newRoomId());
            try {
              other.conn.side = room.join(other.ws, other.name, other.deck);
              other.conn.room = room;
              conn.side = room.join(ws, m.name, m.deck);
              conn.room = room;
            } catch (e) {
              room.dispose();
              other.conn.room = null;
              waiting.unshift(other);
              throw e;
            }
            rooms.set(room.id, room);
            room.begin();
            return;
          }
          case "unqueue":
            dequeue(conn);
            return send({ t: "unqueued" });
          case "leave": {
            dequeue(conn);
            if (conn.room) {
              conn.room.leave(ws);
              conn.room = null;
              conn.side = -1;
            }
            return send({ t: "unqueued" });
          }
          case "ready":
          case "declare":
          case "pass":
          case "assign_late":
          case "confirm_assign":
            if (!conn.room) return err("no_room", "\u4F60\u8FD8\u6CA1\u8FDB\u623F\u95F4", seq);
            conn.room.handle(conn.side, m);
            return;
          default:
            return err("bad_type", `\u4E0D\u8BA4\u8BC6\u7684\u6D88\u606F ${String(m.t).slice(0, 16)}`, seq);
        }
      } catch (e) {
        if (e instanceof RoomError) return err(e.code, e.message, seq);
        console.error(e);
        return err("internal", "\u670D\u52A1\u5668\u51FA\u9519\u4E86", seq);
      }
    });
    ws.on("close", () => {
      dequeue(conn);
      conn.room?.disconnect(ws);
    });
    ws.on("error", () => {
    });
  });
  const gc = setInterval(() => {
    for (const [id, r] of rooms) if (!r.anyConnected() && r.idleMs() > ROOM_IDLE_MS) {
      r.dispose();
      rooms.delete(id);
    }
  }, 6e4);
  gc.unref();
  return new Promise((ok, bad) => {
    server.once("error", bad);
    server.listen(opts.port ?? 8787, opts.host ?? "0.0.0.0", () => {
      const port = server.address().port;
      ok({
        server,
        port,
        rooms,
        waiting,
        close: () => new Promise((r) => {
          clearInterval(gc);
          for (const room of rooms.values()) room.dispose();
          for (const c of wss.clients) c.terminate();
          wss.close();
          server.close(() => r());
          server.closeAllConnections?.();
        })
      });
    });
  });
}
var VIRT_MAC = ["08:00:27", "0a:00:27", "00:50:56", "00:0c:29", "00:05:69", "00:1c:14", "00:15:5d", "02:42:", "00:1c:42", "00:16:3e", "52:54:00"];
var isPrivate = (a) => a.startsWith("192.168.") || a.startsWith("10.") || /^172\.(1[6-9]|2\d|3[01])\./.test(a);
function classifyAddrs(list, primary) {
  const out = [];
  for (const { ip, name, mac } of list) {
    const m = mac.toLowerCase();
    const virt = VIRT_MAC.some((p) => m.startsWith(p)) || /vEthernet|WSL|Hyper-V|VMware|VirtualBox|Docker|VMnet|br-|docker|veth/i.test(name) || /^198\.1[89]\./.test(ip);
    const mesh = /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(ip) || /ZeroTier|Tailscale|蒲公英|Radmin|Hamachi/i.test(name);
    if (virt) out.push({ ip, name, rank: 4, note: "\u865A\u62DF\u7F51\u5361\uFF0C\u4E0D\u662F\u8FD9\u4E2A" });
    else if (mesh) out.push({ ip, name, rank: 3, note: "\u7EC4\u7F51\u5DE5\u5177\u7684\u5730\u5740\uFF1A\u4E0D\u5728\u540C\u4E00\u4E2A Wi-Fi \u7684\u670B\u53CB\u7528\u8FD9\u4E2A" });
    else if (ip === primary) out.push({ ip, name, rank: 0, note: "\u2190 \u53D1\u8FD9\u4E2A\u7ED9\u670B\u53CB" });
    else if (ip.startsWith("192.168.137.")) out.push({ ip, name, rank: 1, note: "\u8FD9\u53F0\u7535\u8111\u5F00\u7684\u79FB\u52A8\u70ED\u70B9\uFF1A\u8FDE\u8FD9\u4E2A\u70ED\u70B9\u7684\u670B\u53CB\u7528\u5B83" });
    else out.push({ ip, name, rank: isPrivate(ip) ? 1 : 2, note: "" });
  }
  out.sort((x, y) => x.rank - y.rank);
  if (!out.some((x) => x.rank === 0)) {
    const best = out.find((x) => x.rank === 1 && !x.ip.startsWith("192.168.137."));
    if (best) best.note = "\u2190 \u591A\u534A\u662F\u8FD9\u4E2A";
  }
  return out;
}
function primaryIp() {
  return new Promise((ok) => {
    const s = createSocket("udp4");
    const done = (ip) => {
      try {
        s.close();
      } catch {
      }
      ok(ip);
    };
    s.on("error", () => done(""));
    try {
      s.connect(53, "223.5.5.5", () => {
        try {
          done(s.address().address);
        } catch {
          done("");
        }
      });
    } catch {
      done("");
    }
  });
}
async function lanAddrs() {
  const list = [];
  for (const [name, l] of Object.entries(networkInterfaces())) for (const i of l ?? []) if (i.family === "IPv4" && !i.internal) list.push({ ip: i.address, name, mac: i.mac });
  return classifyAddrs(list, await primaryIp());
}
function fetchText(port, path) {
  return new Promise((ok) => {
    const req = httpGet({ host: "127.0.0.1", port, path, timeout: 800 }, (res) => {
      let body = "";
      res.setEncoding("utf8");
      res.on("data", (d) => {
        if (body.length < 2e4) body += d;
      });
      res.on("end", () => ok(body));
    });
    req.on("timeout", () => {
      req.destroy();
      ok("");
    });
    req.on("error", () => ok(""));
  });
}
async function whoIsOn(port) {
  if ((await fetchText(port, "/__cizhan")).trim() === HELLO) return "ours";
  return /词战|word-combat|ci-zhan/i.test(await fetchText(port, "/")) ? "old" : "other";
}
function printAddrs(port, addrs) {
  if (!addrs.length) {
    console.log("\u6CA1\u627E\u5230\u5C40\u57DF\u7F51\u5730\u5740\uFF1A\u8FD9\u53F0\u7535\u8111\u597D\u50CF\u6CA1\u8FDE Wi-Fi / \u7F51\u7EBF\u3002\u8FDE\u4E0A\u4EE5\u540E\u8FD9\u91CC\u4F1A\u81EA\u52A8\u663E\u793A\u65B0\u5730\u5740\u3002");
    return;
  }
  console.log("\u670B\u53CB\uFF08\u548C\u623F\u4E3B\u8FDE\u540C\u4E00\u4E2A Wi-Fi / \u8DEF\u7531\u5668\uFF09\u6253\u5F00\uFF1A");
  for (const a of addrs) console.log(`    http://${a.ip}:${port}/    [${a.name}]${a.note ? "  " + a.note : ""}`);
}
async function printHowTo(port) {
  const L = (s = "") => console.log(s);
  L("\u623F\u4E3B\uFF1A\u7528\u6D4F\u89C8\u5668\u6253\u5F00   http://localhost:" + port + "/");
  printAddrs(port, await lanAddrs());
  L();
  L("\u4E24\u4E2A\u4EBA\u90FD\u5728\u4E3B\u83DC\u5355\u70B9\u300C\u6253\u771F\u4EBA\u300D\u2192 \u9009\u5361\u7EC4 \u2192\u300C\u5F00\u59CB\u5339\u914D\u300D\uFF0C\u4E24\u4E2A\u4EBA\u90FD\u70B9\u4E86\u5C31\u81EA\u52A8\u5F00\u6253\u3002");
  L("\u670B\u53CB\u8FDE\u4E0D\u4E0A\uFF1A\u53CC\u51FB\u300C\u5F00\u653E\u9632\u706B\u5899.bat\u300D\uFF0C\u6216\u770B\u300C\u8054\u673A\u8BF4\u660E.txt\u300D\u7B2C\u4E94\u8282\u3002");
}
function watchAddrs(port) {
  let last = "";
  const key = (a) => a.map((x) => `${x.ip}/${x.rank}`).join(",");
  void lanAddrs().then((a) => {
    last = key(a);
  });
  setInterval(async () => {
    const a = await lanAddrs(), k = key(a);
    if (k === last) return;
    last = k;
    console.log();
    console.log(`\u2014\u2014 \u7F51\u7EDC\u53D8\u4E86\uFF08\u6362\u4E86 Wi-Fi\uFF1F\uFF09${(/* @__PURE__ */ new Date()).toLocaleTimeString()}\uFF0C\u65B0\u7684\u5730\u5740 \u2014\u2014`);
    printAddrs(port, a);
  }, 5e3).unref();
}
async function main() {
  const host = process.env.HOST ?? "0.0.0.0";
  const want = +(process.env.PORT ?? 8787);
  console.log("===== \u8BCD\u6218 \xB7 \u5C40\u57DF\u7F51\u8054\u673A\u670D\u52A1\u5668 =====");
  for (let port = want; port < want + 12; port++) {
    try {
      const r = await startServer({ port, host });
      if (port !== want) console.log(`\uFF08\u7AEF\u53E3 ${want} \u88AB\u5360\u7740\uFF0C\u8FD9\u6B21\u6539\u7528 ${port}\uFF0C\u4E0B\u9762\u7684\u5730\u5740\u5C31\u662F\u65B0\u7248\u7684\u5730\u5740\uFF09`);
      console.log(`\u670D\u52A1\u5668\u5DF2\u542F\u52A8\uFF0C\u7AEF\u53E3 ${r.port}\u3002\u8FD9\u4E2A\u7A97\u53E3\u522B\u5173\uFF0C\u5173\u4E86\u670D\u52A1\u5668\u5C31\u505C\u4E86\u3002`);
      console.log();
      await printHowTo(r.port);
      watchAddrs(r.port);
      return;
    } catch (e) {
      if (e?.code !== "EADDRINUSE") {
        console.error("\u542F\u52A8\u5931\u8D25\uFF1A", e?.message ?? e);
        process.exit(1);
      }
      const who = await whoIsOn(port);
      if (who === "ours") {
        console.log(`\u5DF2\u7ECF\u6709\u4E00\u4E2A\u8BCD\u6218\u670D\u52A1\u5668\u5728\u8FD0\u884C\u4E86\uFF08\u7AEF\u53E3 ${port}\uFF09\uFF0C\u4E0D\u7528\u518D\u5F00\u7B2C\u4E8C\u4E2A\u3002`);
        console.log("\u76F4\u63A5\u7528\u4E0B\u9762\u7684\u5730\u5740\uFF1B\u8981\u91CD\u5F00\u7684\u8BDD\uFF0C\u5148\u628A\u4E4B\u524D\u90A3\u4E2A\u670D\u52A1\u5668\u7A97\u53E3\u5173\u6389\u518D\u53CC\u51FB start.bat\u3002");
        console.log();
        await printHowTo(port);
        process.exit(0);
      }
      if (who === "old") {
        console.log(`\u7AEF\u53E3 ${port} \u4E0A\u5F00\u7740\u4E00\u4E2A\u3010\u65E7\u7248\u3011\u8BCD\u6218\u670D\u52A1\u5668\uFF08\u4EE5\u524D\u7559\u4E0B\u7684\uFF09\uFF0C\u6D4F\u89C8\u5668\u6253\u5F00 ${port} \u770B\u5230\u7684\u662F\u65E7\u7248\u3002`);
        console.log(`\u8FD9\u6B21\u65B0\u7248\u6362\u4E2A\u7AEF\u53E3\u542F\u52A8\uFF1B\u60F3\u5173\u6389\u65E7\u7684\uFF0C\u53CC\u51FB\u300C\u5173\u95ED\u65E7\u670D\u52A1\u5668.bat\u300D\u3002`);
        console.log();
      }
    }
  }
  console.error(`\u542F\u52A8\u5931\u8D25\uFF1A\u7AEF\u53E3 ${want}\uFF5E${want + 11} \u90FD\u88AB\u5360\u7528\u4E86\u3002\u91CD\u542F\u7535\u8111\u540E\u518D\u8BD5\uFF0C\u6216\u8005\u5148 set PORT=9000 \u518D\u8FD0\u884C\u3002`);
  process.exit(1);
}
if (process.argv[1] && fileURLToPath(import.meta.url) === resolve2(process.argv[1])) void main();
export {
  classifyAddrs,
  startServer
};
